package com.highwho.qrbinding.etag;

import android.app.Activity;
import android.content.Intent;

/**
 * Created by xyz on 3/3/16.
 */
public abstract class ETagDetector<E extends ETag> {

    public interface DetectETagListener<E> {
        boolean onDetectETag(E eTag);
    }
    protected Activity activity;

    protected DetectETagListener<E> eTagListener;

    public ETagDetector(Activity activity) {
        this.activity = activity;
    }

    public ETagDetector<E> setETagListener(DetectETagListener<E> eTagListener) {
        this.eTagListener = eTagListener;
        return this;
    }

    protected abstract E onFilterIntent(Intent intent, int requestCode, int resultCode);


    protected void callBack(E e) {
        if(this.eTagListener != null && e != null) {
            this.eTagListener.onDetectETag(e);
        }
    }

    public void filterIntent(Intent intent, int requestCode, int resultCode) {
        E etag = onFilterIntent(intent, requestCode, resultCode);
        this.callBack(etag);
    }
}

package com.highwho.qrbinding.datasource.repository;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.highwho.qrbinding.datasource.DatabaseManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by xyz on 3/13/16.
 */
public abstract class Repository<E, K> {
    private DatabaseManager databaseManager;
    protected SQLiteDatabase database;

    public Repository(DatabaseManager databaseManager) {
        this.database = databaseManager.openDatabase();
        this.databaseManager = databaseManager;
    }

    protected abstract String getTableName();

    protected abstract E mapRecordToEntity(Cursor cursor);

    protected abstract String getIdFieldName();

    public E findById(K id) {
        Cursor cursor = null;
        try {
            cursor = database.query(getTableName(), new String[]{"*"}, getIdFieldName() + "=?", new String[]{id.toString()}, null, null, null);
            E item = null;
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                item = mapRecordToEntity(cursor);
            }
            return item;
        } finally {
            if (cursor != null && !cursor.isClosed()) cursor.close();
        }
    }

    public List<E> findAll(String sort) {
        try (Cursor cursor =
                     database.query(getTableName(), new String[]{"*"}, null, null, null, null, sort)
        ) {
            return toDataList(cursor);
        }
    }

    public abstract E save(E entity);


    public List<E> findByRange(int start, int limit, String sort) {
        String limitStr = String.format(Locale.CHINA, "%d, %d", start, limit);
        try (Cursor cursor =
                     database.query(getTableName(), new String[]{"*"}, null, null, null, null, sort, limitStr)
        ) {
            return toDataList(cursor);
        }
    }

    public void close() {
//        databaseManager.closeDatabase();
    }

    protected List<E> toDataList(Cursor cursor) {
        List<E> result = new ArrayList<>(cursor.getCount());
        while (cursor.moveToNext()) {
            E item = mapRecordToEntity(cursor);
            result.add(item);
        }
        return result;
    }
}

package com.highwho.qrbinding.etag.nfc;

import android.net.Uri;
import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.tech.Ndef;

import com.highwho.qrbinding.etag.ETagException;
import com.highwho.qrbinding.etag.TagDataExtractor;
import com.nxp.nfclib.utils.Utilities;

import java.io.IOException;

/**
 * Created by xyz on 3/3/16.
 */
public class NdefUriExtractor implements TagDataExtractor<NfcTag, Uri> {
    @Override
    public String getKey(NfcTag eTag) throws ETagException {
        return Utilities.byteToHexString(eTag.getSystemTag().getId());
    }

    @Override
    public Uri extract(NfcTag eTag) throws ETagException {
        Ndef ndef = null;
        try {
            ndef = Ndef.get(eTag.getSystemTag());
            if(ndef == null) {
                throw new ETagException("can not get for ndef");
            }
            ndef.connect();
            NdefMessage message = ndef.getNdefMessage();
            if(message == null) throw new ETagException("ndef message is empty");
            NdefRecord[] records = message.getRecords();
            if(records.length > 0) {
                return records[0].toUri();
            }else {
                throw new ETagException("ndef record count is 0");
            }
        } catch (IOException | FormatException e) {
            e.printStackTrace();
            throw new ETagException(e);
        } finally {
            if(ndef != null && ndef.isConnected()) {
                try {
                    ndef.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }


}

package com.highwho.qrbinding.fragment;

import android.app.Fragment;
import android.app.LoaderManager;
import android.content.Loader;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.highwho.qrbinding.R;
import com.highwho.qrbinding.common.loader.PageLoader;
import com.highwho.qrbinding.common.view.EndlessScrollListener;
import com.highwho.qrbinding.common.view.MutableRecyclerAdapter;
import com.highwho.qrbinding.datasource.DatabaseManager;
import com.highwho.qrbinding.datasource.repository.SEntityRepository;
import com.highwho.qrbinding.entity.ScannedEntity;

import java.util.List;

/**
 * Created by xyz on 3/4/16.
 */
public class SEntitiesFragment extends Fragment implements LoaderManager.LoaderCallbacks<List<ScannedEntity>> {
    public interface SickbedSelectionHandler {
        void handleEntitySelected(View view, ScannedEntity scannedEntity);
    }

    private SEntityRepository repository;
    private PageLoader<ScannedEntity> pageLoader;
    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;
    private ScannedRowAdapter mAdapter;
    private EndlessScrollListener scrollListener;
    private SickbedSelectionHandler selectionHandler;
    private SwipeRefreshLayout refreshLayout;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.sickbed_list, container, false);
        initRecyclerView(view);
        if (this.getActivity() instanceof SickbedSelectionHandler) {
            this.selectionHandler = (SickbedSelectionHandler) this.getActivity();
        }

        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        repository = new SEntityRepository(DatabaseManager.getWiseInstance(this.getActivity()));
        getLoaderManager().initLoader(0, null, this);
    }

    private void initRecyclerView(View view) {

        mRecyclerView = (RecyclerView) view.findViewById(R.id.sickbed_recycler_view);
        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this.getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);

        mAdapter = new ScannedRowAdapter(this.getActivity());

        mAdapter.setOnRecycleItemTouchListener(new MutableRecyclerAdapter.OnRecycleItemTouchListener<View>() {
            @Override
            public boolean onItemClickEvent(MutableRecyclerAdapter.ViewHolder<View> vm, View v) {
                if (SEntitiesFragment.this.selectionHandler != null) {
                    SEntitiesFragment.this.selectionHandler.handleEntitySelected(v, mAdapter.getItemData(vm.getAdapterPosition()));
                }
                return false;
            }
        });

        mRecyclerView.setAdapter(mAdapter);

        scrollListener = new EndlessScrollListener(mLayoutManager) {
            @Override
            public void onLoadMore(int totalItemsCount, boolean toBottom) {
                if (pageLoader != null) {
                    pageLoader.requestNextPage(totalItemsCount);
                }
            }
        };

        mRecyclerView.setOnScrollListener(scrollListener);

        refreshLayout =
                (SwipeRefreshLayout) view.findViewById(R.id.swipe_refresh_layout);
        refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if(!pageLoader.requestNextPage(0)) {
                    refreshLayout.setRefreshing(false);
                }
            }
        });
    }



    @Override
    public Loader<List<ScannedEntity>> onCreateLoader(int id, Bundle args) {
        pageLoader = new PageLoader<ScannedEntity>(this.getActivity()) {
            @Override
            protected List<ScannedEntity> loadPageData(int start, int pageSize) {
                String sort = ScannedEntity.Schema.COLUMN_CREATE_TIME + " DESC";
                return repository.findByRange(start, pageSize, sort);
            }
        };
        return pageLoader;
    }

    @Override
    public void onLoadFinished(Loader<List<ScannedEntity>> loader, List<ScannedEntity> data) {
        if (loader == pageLoader) {
            if(refreshLayout.isRefreshing()) {
                mAdapter.clearData(true);
                refreshLayout.setRefreshing(false);
            }
            mAdapter.updateData(data, pageLoader.getIndex(), true);
        }
    }

    @Override
    public void onLoaderReset(Loader loader) {
        Log.i("loader rest", loader.toString());
    }
}
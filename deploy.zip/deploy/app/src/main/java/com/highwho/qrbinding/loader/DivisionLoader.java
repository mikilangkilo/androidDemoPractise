package com.highwho.qrbinding.loader;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.highwho.qrbinding.App;
import com.highwho.qrbinding.common.http.WiseJsonArrayRequest;
import com.highwho.qrbinding.common.loader.volley.SqlVolleyArrayLoader;
import com.highwho.qrbinding.datasource.repository.Repository;
import com.highwho.qrbinding.entity.DivisionEntity;
import com.highwho.qrbinding.entity.HospitalEntity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

/**
 * Created by xyz on 8/5/16.
 */
public class DivisionLoader extends SqlVolleyArrayLoader<DivisionEntity, Integer> {

    public DivisionLoader(Context context, RequestQueue requestQueue, boolean mSync, Repository<DivisionEntity, Integer> repository) {
        super(context, requestQueue, mSync, repository);
    }

    public DivisionLoader(Context context, boolean mSync, Repository<DivisionEntity, Integer> repository) {
        super(context, mSync, repository);
    }

    public DivisionLoader(Context context, Repository<DivisionEntity, Integer> repository) {
        super(context, repository);
    }


    @Override
    protected WiseJsonArrayRequest initRequest(Response.Listener<JSONArray> listener, Response.ErrorListener errorListener) {
        return new WiseJsonArrayRequest(
                Request.Method.GET,
                App.preferenceReader(this.getContext()).getApiUri("/nodeset/hospital_divisions?limit=10000"),
                null,
                listener,
                errorListener,
                App.authenticManager(this.getContext()).getToken());
    }

    @Override
    protected void dumpDataToDB(List<DivisionEntity> dataList, Repository<DivisionEntity, Integer> repository) {
        for (DivisionEntity entity : dataList) {
//            Log.d("divisionloader", "dumpDataToDB with id:" + entity.getId().toString());
            entity = repository.save(entity);
        }
    }

    @Override
    protected List<DivisionEntity> queryDataFromDB(Repository<DivisionEntity, Integer> repository) {
        return repository.findAll("");
    }

    @Override
    protected DivisionEntity mapArrayItemToData(JSONArray jsonArray, int index) {
        try {
            JSONObject jsonObject = jsonArray.getJSONObject(index);
            DivisionEntity division = new DivisionEntity();
            division.setId(jsonObject.getInt("id"));
            division.setName(jsonObject.optString("name"));

            JSONObject hospital = jsonObject.optJSONObject("hospital");
            if (hospital == null) {
                System.out.println(jsonObject.toString());
                Log.e("DivisionLoader", "division " + division.getId() + " json can not get hospital");
                return division;
            }
            JSONObject link = hospital.optJSONObject("link");
            if (link == null) {
                System.out.println(jsonObject.toString());
                Log.e("DivisionLoader", "division " + division.getId() + " json can not get hospital.link");
                return division;
            }
            int hospitalId = link.optInt("id");
            if (hospitalId == 0) {
                System.out.println(jsonObject.toString());
                Log.e("DivisionLoader", "division" + division.getId() +" json can not get hospital.link.id");
                return division;
            }
            division.setHospitalId(hospitalId);
            return division;
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void onVolleyLoadedWithError(VolleyError error) {
        String text = "网络跟新失败:";
        if (error.networkResponse != null) {
            if (error.networkResponse.statusCode == 401) {
                text = text + "验证失败";
            } else {
                text = text + error.networkResponse.statusCode;
            }
        } else {
            text += error.getMessage();
        }
        Log.e("HospitalsLoader", "onVolleyLoadedWithError", error);
        Toast.makeText(this.getContext(), text, Toast.LENGTH_SHORT).show();
    }

}

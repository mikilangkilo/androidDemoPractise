package com.highwho.qrbinding.datasource.repository;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.highwho.qrbinding.datasource.DatabaseManager;
import com.highwho.qrbinding.entity.DivisionEntity;
import com.highwho.qrbinding.entity.HospitalEntity;
import com.highwho.qrbinding.entity.ScannedEntity;

import java.util.List;

/**
 * Created by xyz on 7/25/16.
 */
public class DivisionRepository extends Repository<DivisionEntity, Integer> {

    public DivisionRepository(DatabaseManager databaseManager) {
        super(databaseManager);
    }

    @Override
    protected String getTableName() {
        return DivisionEntity.Schema.TABLE_NAME;
    }

    @Override
    protected DivisionEntity mapRecordToEntity(Cursor cursor) {
        int columnIndex = -1;
        DivisionEntity entity = new DivisionEntity();
        columnIndex = cursor.getColumnIndex(DivisionEntity.Schema._ID);
        if(columnIndex >= 0) {
            entity.setId(cursor.getInt(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(DivisionEntity.Schema.COLUMN_NAME);
        if(columnIndex >= 0) {
            entity.setName(cursor.getString(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(DivisionEntity.Schema.COLUMN_HOSPITAL_ID);
        if(columnIndex >= 0) {
            entity.setHospitalId(cursor.getInt(columnIndex));
        }
        return entity;
    }

    @Override
    protected String getIdFieldName() {
        return HospitalEntity.Schema._ID;
    }

    @Override
    public DivisionEntity save(DivisionEntity entity) {
        ContentValues contentValues = new ContentValues(3);
        if(entity.getId() != null) contentValues.put(DivisionEntity.Schema._ID, entity.getId());
        if(entity.getName() != null) contentValues.put(DivisionEntity.Schema.COLUMN_NAME, entity.getName());
        if(entity.getHospitalId() != null) contentValues.put(DivisionEntity.Schema.COLUMN_HOSPITAL_ID, entity.getHospitalId());
        long rowId = database.insertWithOnConflict(getTableName(), null, contentValues, SQLiteDatabase.CONFLICT_REPLACE);
        if(rowId < 0) {
            throw new RuntimeException("insert row id:" + rowId);
        }
        return entity;
    }


    public List<DivisionEntity> findByHospitalId(Integer hospitalId) {
        try (Cursor cursor =
                     database.query(DivisionEntity.Schema.TABLE_NAME, new String[]{"*"}, DivisionEntity.Schema.COLUMN_HOSPITAL_ID + "=?", new String[]{hospitalId.toString()}, null, null, null);
        ) {
            return toDataList(cursor);
        }
    }
}

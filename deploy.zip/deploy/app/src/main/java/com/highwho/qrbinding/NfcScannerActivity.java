package com.highwho.qrbinding;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.MifareUltralight;
import android.nfc.tech.Ndef;
import android.nfc.tech.NfcA;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;


import com.nxp.nfclib.utils.Utilities;

import java.io.IOException;
import java.nio.charset.Charset;

/**
 * Created by xyz on 2/26/16.
 */
public class NfcScannerActivity extends Activity {
    private NfcAdapter nfcAdapter;
    private IntentFilter[] intentFilters;
    private PendingIntent pendingIntent;
    private String[][] techListsArray;

    //sdk
//    private NxpNfcLibLite libInstance = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nfc_scanner);
//        NdefRecord ndefRecord = NdefRecord.createUri("http://w-se.cn/61B21KV7bvO");
//        NdefMessage ndefMessage = new NdefMessage(ndefRecord);

//        Log.i("!!!!!!!!!!", idToString(ndefMessage.toByteArray()));

        pendingIntent = PendingIntent.getActivity(
                this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
        IntentFilter ndef = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);

        try {
            nfcAdapter = NfcAdapter.getDefaultAdapter(this);
            ndef.addDataType("*/*");
            techListsArray = new String[][] { new String[] { NfcA.class.getName(), Ndef.class.getName()} };
            intentFilters = new IntentFilter[] {ndef, };
        } catch (IntentFilter.MalformedMimeTypeException e) {
            e.printStackTrace();
        }

/*        libInstance = NxpNfcLibLite.getInstance();
        libInstance.registerActivity(this);*/
    }

    public void onPause() {
//        libInstance.stopForeGroundDispatch();
        super.onPause();
        nfcAdapter.disableForegroundDispatch(this);

    }

    public void onResume() {
//        libInstance.startForeGroundDispatch();
        super.onResume();
        nfcAdapter.enableForegroundDispatch(this, pendingIntent, intentFilters, techListsArray);
    }

    public void onNewIntent(Intent intent) {
        System.out.println("intent.getAction()" + intent.getAction());
        if (NfcAdapter.ACTION_TECH_DISCOVERED.equals(intent.getAction())) {

            Tag tagFromIntent = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            String content = idToString(tagFromIntent.getId());
            Ndef ndef = Ndef.get(tagFromIntent);
            System.out.println("MifareUltralight get");
            try {
                ndef.connect();
                NdefRecord uriRecord = new NdefRecord(
                        NdefRecord.TNF_ABSOLUTE_URI ,
                        "http://w-se.cn/ABCDEFGHIJK".getBytes(Charset.forName("US-ASCII")),
                        new byte[0], new byte[0]);
                ndef.writeNdefMessage(new NdefMessage(uriRecord));
                System.out.println("aaaaaaaaaa save ndef success");
            } catch (IOException e) {
                e.printStackTrace();
            } catch (FormatException e) {
                e.printStackTrace();
            }finally {
                if (ndef != null) {
                    try {
                        ndef.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

//            MifareUltralight mifare = MifareUltralight.get(tagFromIntent);

//            try{
//                mifare.connect();
//                byte[] payload = mifare.readPages(4);
////                Log.d("nfc bytes for page 4", idToString(payload));
////                content = new String(payload, Charset.forName("US-ASCII"));
////                content = idToString(payload);
//            }catch (IOException e) {
//                e.printStackTrace();
//            } finally {
//                if(mifare != null) {
//                    try {
//                        mifare.close();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }

            ((TextView) findViewById(R.id.text_nfc_content)).setText(content);
        }

        //do something with tagFromIntent
        /*Nxpnfcliblitecallback callback = new Nxpnfcliblitecallback() {
            @Override
            public void onClassicEV1CardDetected(IMFClassicEV1 imfClassicEV1) {
//                Log.i("onClassicEV1Card", "UltraLight Card Detected");
            }

            public void onNTag203xCardDetected(INTag203x var1) {
                // TODO Auto-generated method stub

                try {
                    Log.i("onNTag203xCard", "UltraLight Card Detected");
                    var1.getReader().connect();
//                    Log.i("onNTag203xCard", "content:" + new String(var1.read(var1.getFirstUserpage()), Charset.forName("US-ASCII")));
//                    Log.i("onNTag203xCard", "getFirstUserpage:" + var1.getFirstUserpage());
//                    var1.getCardDetails().toString();
//                    ((TextView) findViewById(R.id.text_nfc_content)).setText(idToString(var1.read(0)));

//                    NdefRecord ndefRecord = NdefRecord.createUri("http://w-se.cn/61B21KV7bvO");
//                    NdefMessage ndefMessage = new NdefMessage(ndefRecord);
//                    var1.writeNDEF(ndefMessage);
//                    Log.i("onNTag203xCard", "save NdefMessage !!!!!");
                    NdefMessage ndefMessage =  new NdefMessage(var1.readNDEF().toByteArray());
                    Log.i("onNTag203xCard", "get NdefMessage !!!!!");
                    String sMsg = new String(ndefMessage.getRecords()[0].getPayload());

                    ((TextView) findViewById(R.id.text_nfc_content)).setText(sMsg);

//                    ((TextView) findViewById(R.id.text_nfc_content)).setText(Utilities.du(var1.read(var1.getFirstUserpage())));
                } catch (ReaderException e1) {
                    e1.printStackTrace();
                } catch (SmartCardException e1) {
                    e1.printStackTrace();
                } catch (IOException e1) {
                    e1.printStackTrace();
                } catch (FormatException e1) {
                    e1.printStackTrace();
                } finally {
                    if(var1.getReader().isConnected()) {
                        try {
                            var1.getReader().close();
                        } catch (ReaderException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        };
        try {
            libInstance.filterIntent(intent, callback);
        } catch (CloneDetectedException e) {
            e.printStackTrace();
        }*/
    }

    private String idToString(byte[] id) {
        String str = new String();
        for (int i = 0; i < id.length; i++) {
            str += String.format(":%02X", id[i]);
        }
        return str.isEmpty() ? "" : str.substring(1);
    }

}

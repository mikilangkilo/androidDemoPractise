package com.highwho.qrbinding.common.loader.volley;

/**
 * Created by xyz on 3/12/16.
 */
public class LoaderContent<D> {
    private D data;
    private Exception exception;

    public LoaderContent(D data, Exception exception) {
        this.data = data;
        this.exception = exception;
    }

    public D getData() {
        return data;
    }

    public Exception getException() {
        return exception;
    }
}

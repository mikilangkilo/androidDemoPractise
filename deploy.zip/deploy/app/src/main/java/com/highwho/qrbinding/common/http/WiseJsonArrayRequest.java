package com.highwho.qrbinding.common.http;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by xyz on 6/23/16.
 */
public class WiseJsonArrayRequest extends JsonArrayRequest {
    private String token;
    public WiseJsonArrayRequest(int method, String url, String requestBody, Response.Listener<JSONArray> listener, Response.ErrorListener errorListener, String token) {
        super(method, url, requestBody, listener, errorListener);
        this.token = token;
    }

    @Override
    public Map<String, String> getHeaders() throws AuthFailureError {
        Map<String, String> heardes = new HashMap<>(super.getHeaders());
        heardes.put("token", token);
        return heardes;
    }
}

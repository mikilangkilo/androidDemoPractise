package com.highwho.qrbinding.etag;

/**
 * Created by xyz on 3/3/16.
 */
public interface TagDataExtractor<E extends ETag, T> {
    String getKey(E eTag) throws ETagException;
    T extract(E eTag) throws ETagException;
}

package com.highwho.qrbinding;

import android.app.Fragment;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.highwho.qrbinding.datasource.QrSickbed;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by xyz on 2/21/16.
 */
public class BindingFragment extends Fragment {

    public interface BindingSickBed {
        boolean bindData(QrSickbed qrSickbed);
    }

    private BindingSickBed bindingSickBed;

    private QrSickbed qrSickbed;

    public BindingFragment() {
        qrSickbed = new QrSickbed();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.bindingSickBed = (BindingSickBed) getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.binding, container, false);
        setContent(view);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(v.getApplicationWindowToken(), 0);
            }
        });

        ((Button) view.findViewById(R.id.btn_binding)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lanuchBinding();
            }
        });
        ((EditText) view.findViewById(R.id.edit_division)).setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    lanuchBinding();
                    InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getApplicationWindowToken(), 0);
                    return true;
                }
                return false;
            }
        });
        return view;
    }

    private void setPromptText(String text, boolean warning) {
        TextView textView = ((TextView) getView().findViewById(R.id.binding_prompt));
        textView.setText(text);
        if(warning) {
            textView.setTextColor(Color.RED);
        } else {
            textView.setTextColor(Color.GREEN);
        }
    }

    private boolean isAutoFill() {
         return ((Switch) getView().findViewById(R.id.switch_number_auto)).isChecked();
    }

    private boolean isNumberUp() {
        return ((CheckBox) getView().findViewById(R.id.checkbox_number_up)).isChecked();
    }

    private boolean isAutoWrite() {
        return ((CheckBox) getView().findViewById(R.id.checkbox_qr_auto_write)).isChecked();
    }

    public void lanuchBinding() {
        if (bindingSickBed != null) {
            qrSickbed.setDivision(getDivision());
            qrSickbed.setBedNumber(getBedNumber());
            try {
                bindingSickBed.bindData(qrSickbed);
                setPromptText("绑定数据记录成功", false);
//                Toast.makeText(getActivity(), "绑定数据记录成功", Toast.LENGTH_LONG).show();
            } catch (RuntimeException e) {
                setPromptText("失败:" + e.getMessage(), true);
//                Toast.makeText(getActivity(), "失败:" + e.getMessage(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }

        }
    }

    private void setContent(View view) {
        if (view == null) return;
        String qrId = "无内容";
        String bedNumber = "";
        String division = "";

        if (qrSickbed.getQrCode() != null && qrSickbed.getQrCode().length() > 0) {
            qrId = qrSickbed.getQrCode();
        }

        TextView textView = (TextView) view.findViewById(R.id.qr_id_content);
        textView.setText(qrId);

        if (qrSickbed.getBedNumber() != null) {
            textView = (TextView) view.findViewById(R.id.edit_sickbed);
            textView.setText(qrSickbed.getBedNumber());
        }

        if (qrSickbed.getDivision() != null) {
            textView = (TextView) view.findViewById(R.id.edit_division);
            textView.setText(qrSickbed.getDivision());
        }
    }

    private String getBedNumber() {
        View view = getView();
        if (view == null) return null;
        TextView textView = (TextView) view.findViewById(R.id.edit_sickbed);
        return textView.getText().toString();
    }

    private String getDivision() {
        View view = getView();
        if (view == null) return null;
        TextView textView = (TextView) view.findViewById(R.id.edit_division);
        return textView.getText().toString();
    }

    private void forceKeyBoard() {
        /*EditText editText = (EditText) getView().findViewById(R.id.edit_sickbed);
        editText.requestFocus();
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);*/
    }

    public void updateData(QrSickbed in, boolean beError, boolean exist) {

        if (in != null && in.getQrCode() != null && in.getQrCode().length() > 0 ) {
            if(!in.getQrCode().equals(qrSickbed.getQrCode())) {
                this.setPromptText("发现新的病床二维码", false);
            }else{
                this.setPromptText("相同的二维码", false);
            }
            this.qrSickbed.setQrCode(in.getQrCode());
        } else {
            this.setPromptText("二维码格式错误", true);
            return;
        }

        if(exist) {
            String time = "";
            if(in.getCreateTime() != null) time = in.getCreateTime();
            this.setPromptText("已有绑定:" + time, true);
        }


        if(in.getBedNumber() == null || in.getBedNumber().length() == 0 ) {
            in.setBedNumber(autoUpdateNumber(getBedNumber()));
        }

        this.qrSickbed.setBedNumber(in.getBedNumber());

        if(in.getDivision() != null && in.getDivision().length() > 0) {
            this.qrSickbed.setDivision(in.getDivision());
        }

        this.qrSickbed.setNfcId(in.getNfcId());

        setContent(getView());

        if(isAutoWrite()) {
            lanuchBinding();
        }
    }

    private String autoUpdateNumber(String bedNumber) {
        if(!isAutoFill()) {
            return bedNumber;
        }
        String ret = bedNumber;

        try {
            Pattern pattern = Pattern.compile("\\d+");

            Matcher matcher = pattern.matcher(bedNumber);
            boolean found = matcher.find();
            int start = -1;
            int end = -1;
            String group = null;
            while (found) {
                start = matcher.start();
                end = matcher.end();
                group = matcher.group();
                found = matcher.find();
            }
            Log.i("auto fill start", String.valueOf(start));
            Log.i("auto fill end", String.valueOf(end));
            Log.i("auto fill group", String.valueOf(group));

            if(group != null ) {
                int num = Integer.parseInt(group);
                if(isNumberUp()) {
                    ++num;
                } else {
                    --num;
                }
                StringBuilder builder = new StringBuilder(bedNumber.length());
                if(start > 0) {
                    Log.i("bedNumber.substring", bedNumber.substring(0, start));
                    builder.append(bedNumber.substring(0, start));
                }

                builder.append(String.format("%0" + group.length() + "d", num));
                if(end < bedNumber.length()) {
                    builder.append(bedNumber.substring(end));
                }
                ret = builder.toString();
            }
        } catch (RuntimeException e) {
            e.printStackTrace();
            Toast.makeText(getActivity(), "自动填充失败", Toast.LENGTH_SHORT).show();
        }
        return ret;
    }


}

package com.highwho.qrbinding.datasource;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.highwho.qrbinding.entity.DivisionEntity;
import com.highwho.qrbinding.entity.HospitalEntity;
import com.highwho.qrbinding.entity.ScannedEntity;

/**
 * Created by xyz on 3/13/16.
 */
public class WiseDbHelper extends SQLiteOpenHelper {
    private static String CREATE_SICKBED =
            "CREATE TABLE " + ScannedEntity.Schema.TABLE_NAME + " (" +
                    ScannedEntity.Schema._ID + " TEXT PRIMARY KEY," +
                    ScannedEntity.Schema.COLUMN_ENTITY_NAME + " TEXT," +
                    ScannedEntity.Schema.COLUMN_ENTITY_CLASS + " TEXT," +
                    ScannedEntity.Schema.COLUMN_BED_EXTRA + " BOOL," +
                    ScannedEntity.Schema.COLUMN_DIVISION + " TEXT," +
                    ScannedEntity.Schema.COLUMN_HID + " INTEGER," +
                    ScannedEntity.Schema.COLUMN_NFC_ID + " TEXT," +
                    ScannedEntity.Schema.COLUMN_REGION + " TEXT," +
                    ScannedEntity.Schema.COLUMN_BUILDING + " TEXT," +
                    ScannedEntity.Schema.COLUMN_FLOOR + " TEXT," +
                    ScannedEntity.Schema.COLUMN_WARD_NUMBER + " TEXT," +
                    ScannedEntity.Schema.COLUMN_WARD_CAPACITY + " INTEGER," +
                    ScannedEntity.Schema.COLUMN_WARD_GENDER + " INTEGER," +
                    ScannedEntity.Schema.COLUMN_CREATE_TIME + " DATETIME DEFAULT CURRENT_TIMESTAMP," +
                    ScannedEntity.Schema.COLUMN_MODIFY_TIME + " DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL," +
                    ScannedEntity.Schema.COLUMN_MODIFY_SYNCED + " TINYINT NOT NULL" +
                    ");";

    private static String CREATE_HOSPITALS =
            "CREATE TABLE " + HospitalEntity.Schema.TABLE_NAME + " (" +
                    HospitalEntity.Schema._ID + " INT PRIMARY KEY," +
                    HospitalEntity.Schema.COLUMN_NAME + " TEXT," +
                    HospitalEntity.Schema.COLUMN_ADDRESS + " TEXT" +
                    ");";

    private static String CREATE_DIVISIONS =
            "CREATE TABLE " + DivisionEntity.Schema.TABLE_NAME + " (" +
                    DivisionEntity.Schema._ID + " INT PRIMARY KEY," +
                    DivisionEntity.Schema.COLUMN_NAME + " TEXT," +
                    DivisionEntity.Schema.COLUMN_HOSPITAL_ID + " INT" +
                    ")";


    private static String[] INSERT_DIVISION_DATAS =  {"INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (26, '内一科');",
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (27, '内二科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (28, '内三科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (29, '外一科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (30, '外二科（骨科）');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (31, '妇科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (32, '产科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (33, '儿科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (34, '急诊');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (35, '皮肤科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (36, '口腔科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (37, '眼科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (38, '五官科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (39, '推拿科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (40, '针灸科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (41, '中医科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (42, '简易门诊');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (43, '胃镜室');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (44, '检验科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (45, '放射科');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (46, 'B超');" ,
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (47, '心电图');",
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (48, '药剂科');",
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (49, '体检科');",
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (50, '内一科护理');",
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (51, '内二科护理');",
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (52, '外一科护理');",
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (53, '外二科护理');",
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (54, '妇科护理');",
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (55, '急诊科护理');",
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (56, '门诊护理');",
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (57, '财务科');",
            "INSERT INTO " + DivisionEntity.Schema.TABLE_NAME + " VALUES (58, '总务科');"};

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "wise";

    public WiseDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void onCreate(SQLiteDatabase db) {
        db.beginTransaction();
        try {
            db.execSQL(CREATE_HOSPITALS);
            db.execSQL(CREATE_SICKBED);
            db.execSQL(CREATE_DIVISIONS);
//            for (String sql :INSERT_DIVISION_DATAS) {
//                db.execSQL(sql);
//            }
            db.setTransactionSuccessful();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            db.endTransaction();
        }
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

}

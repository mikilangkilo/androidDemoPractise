package com.highwho.qrbinding.common.view.pager;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.support.v13.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xyz on 3/9/16.
 */
public class StripPageAdapter extends FragmentPagerAdapter implements ViewPager.OnPageChangeListener {
    private List<FragmentPageInfo> fragmentInfos;
//    private PagerTabStrip pagerTabStrip;
    private Activity activity;


    public StripPageAdapter(Activity activity) {
        super(activity.getFragmentManager());
        this.activity = activity;
//        pagerTabStrip = (PagerTabStrip) activity.findViewById(R.id.page_tab_strip);
        fragmentInfos = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return fragmentInfos.size();
    }

    @Override
    public Fragment getItem(int position) {
        Log.d("StripPageAdapter", "getItem for position" + position );

        if(fragmentInfos.size() > position) {
            FragmentPageInfo pageInfo = fragmentInfos.get(position);
            return pageInfo.fetchFragment(activity);
        }
        return null;
    }

    public void addFragmentPage(String fragmentName, String title, Bundle bundle) {
        this.fragmentInfos.add(new FragmentPageInfo(fragmentName, title, bundle));

    }

    public List<FragmentPageInfo> getFragmentInfos() {
        return fragmentInfos;
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public CharSequence getPageTitle(int position) {
        String title = "";
        if(fragmentInfos.size() > position) {
            title = fragmentInfos.get(position).getTitle();
        }
        return title;
    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}

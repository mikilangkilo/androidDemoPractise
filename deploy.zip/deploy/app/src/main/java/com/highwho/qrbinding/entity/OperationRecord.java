package com.highwho.qrbinding.entity;

import java.util.Date;

/**
 * Created by xyz on 3/3/16.
 */
public class OperationRecord {
    private int    id = 0;
    private String name;
    private Date   operDate;
    private String data;
}

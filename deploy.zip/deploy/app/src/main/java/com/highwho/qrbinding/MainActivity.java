package com.highwho.qrbinding;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.JsonWriter;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.highwho.qrbinding.datasource.HisDbHelper;
import com.highwho.qrbinding.datasource.QrSickbed;
import com.highwho.qrbinding.nfc.SickbedTagException;
import com.highwho.qrbinding.nfc.SickbedTagManager;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements BindingFragment.BindingSickBed {
    private HisDbHelper hisDbHelper;
    SickbedTagManager sickbedTagManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sickbedTagManager = SickbedTagManager.createManager(this);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.main_toolbar);
        myToolbar.setTitle("hello world");
        setSupportActionBar(myToolbar);
        if (savedInstanceState == null) {
            getFragmentManager().beginTransaction().disallowAddToBackStack().add(R.id.fragment_biding, new BindingFragment()).commit();
        }
        hisDbHelper = new HisDbHelper(this);

//        ((CheckBox) findViewById(R.id.checkbox_nfc_using)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//                try {
//                    sickbedTagManager.enableListener(isChecked);
//                } catch (SickbedTagException e) {
//                    Toast.makeText(buttonView.getContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.bar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.action_export_data:
                exportData(item.getActionView());
                return true;
            case R.id.action_view_data:
                goQrSickbedList(item.getActionView());
                return true;
            case R.id.action_scan_nfc:
                goNfcScanner(item.getActionView());
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
//        findViewById(R.id.main_view).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
//                imm.hideSoftInputFromWindow(v.getApplicationWindowToken(), 0);
//            }
//        });

        SQLiteDatabase db = this.hisDbHelper.getWritableDatabase();
        this.updateQrCount();
    }

    public void onPause() {
        super.onPause();
        sickbedTagManager.stopListener();
    }

    public void onResume() {
        super.onResume();
//        if(((CheckBox) findViewById(R.id.checkbox_nfc_using)).isChecked()) {
//            sickbedTagManager.startListener();
//        }
        sickbedTagManager.startListener();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show();
            } else {
                setQrCodeId(result.getContents(), "");
            }
        }
    }

    public void onNewIntent(Intent intent) {
        String writeUrl = null;
        final Activity context = this;

        SickbedTagManager.SickbedTagCallBack callBack = new SickbedTagManager.SickbedTagCallBack() {
            @Override
            public void onFilterCallback(Uri uri, String code, SickbedTagException e, String nfcId) {
                if(e == null && code == null) {
                    e = new SickbedTagException("code不存在");
                }

                if (e != null) {
                    Toast.makeText(context, "读取失败:" + e.getMessage(), Toast.LENGTH_LONG).show();
                } else {
                    setQrCodeId(uri.toString(), nfcId);
                }
            }
        };
        sickbedTagManager.filter(intent, callBack);
    }

    private void updateQrCount() {
        TextView textView = (TextView) findViewById(R.id.bound_info);
        textView.setText(String.format("total count:%d", hisDbHelper.countQrSickbeds()) );
    }

    private void setQrCodeId(String url, String nfcId) {
        if (url == null) {
            return;
        }
        Uri uri = Uri.parse(url);
        String qrid = null;
        if (uri != null && uri.getHost().contains("w-se.cn") ) {
            qrid = uri.getLastPathSegment();
        }
        BindingFragment fragment = (BindingFragment) getFragmentManager().findFragmentById(R.id.fragment_biding);
        if (fragment != null) {
            boolean exist = false;
            boolean error = false;
            QrSickbed qrSickbed = null;
            if(qrid != null) {
                qrSickbed = hisDbHelper.findById(qrid);
                if(qrSickbed == null) {
                    qrSickbed = new QrSickbed();
                    qrSickbed.setQrCode(qrid);
                } else {
                    exist = true;
                    error = true;
                }
                if(qrSickbed.getNfcId() == null || qrSickbed.getNfcId().length() == 0) {
                    qrSickbed.setNfcId(nfcId);
                }
            } else {
                error = true;
            }
            fragment.updateData(qrSickbed, !error, exist);
        }
    }

    public void onClickScan(View view) {
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setOrientationLocked(false);
        integrator.setCaptureActivity(QrCaptureActivity.class);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
        integrator.setPrompt("please scan sickbed qr code");
        integrator.initiateScan();
    }

    public boolean bindData(QrSickbed qrSickbed) {
        insertOrUpdateQrSickbedData(qrSickbed);
        return true;
    }

    public void exportData(View view) {

        FileOutputStream outputStream = null;
        try{
            if (!isExternalStorageWritable()) {
                throw new IOException("当前磁盘不可写");
            }
            String filename = getResources().getString(R.string.sickbed_file_name);
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss_", Locale.CHINESE);
            filename = dateFormat.format(new Date()) + filename;
            File file = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), filename);
            outputStream = new FileOutputStream(file, false);
            for(QrSickbed qrSickbed:this.hisDbHelper.findAllQrSickbed()) {
                writeSickbedJson(qrSickbed, outputStream);
            }
            outputStream.close();
            Toast.makeText(this, "导出数据成功:", Toast.LENGTH_SHORT).show();
        } catch (IOException e){
            e.printStackTrace();
            Toast.makeText(this, "导出数据失败:" + e.getMessage(), Toast.LENGTH_LONG).show();
            if(outputStream != null) {
                try{
                    outputStream.close();
                }catch (IOException es) {
                    es.printStackTrace();
                }
            }
        }
    }

    private void insertOrUpdateQrSickbedData(QrSickbed qrSickbed) {
        if(qrSickbed == null || qrSickbed.getQrCode() == null || qrSickbed.getQrCode().length() == 0) {
            throw new RuntimeException("qr code 数据是空的");
        }
        hisDbHelper.insertOrUpdateQrSickbed(qrSickbed);
        updateQrCount();
    }

    private void writeSickbedJson(QrSickbed qrSickbed, FileOutputStream fileStream) {
        try {
            JsonWriter writer = new JsonWriter(new OutputStreamWriter(fileStream, "UTF-8"));
            writer.beginObject();
            if(qrSickbed.getQrCode() != null && qrSickbed.getQrCode().length() > 0) {
                writer.name("qrCode").value(qrSickbed.getQrCode());
            }else {
                throw new IOException("qrCode is empty");
            }
            if(qrSickbed.getBedNumber() != null && qrSickbed.getBedNumber().length() > 0) {
                writer.name("bedNumber").value(qrSickbed.getBedNumber());
            }
            if(qrSickbed.getDivision() != null && qrSickbed.getDivision().length() > 0) {
                writer.name("division").value(qrSickbed.getDivision());
            }
            if(qrSickbed.getHid() != null && qrSickbed.getHid() > 0) {
                writer.name("hid").value(qrSickbed.getHid());
            }
            writer.name("nfcId").value(qrSickbed.getNfcId());
            writer.endObject();
            writer.flush();
            fileStream.write("\n".getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void goQrSickbedList(View view) {
        Intent intent = new Intent(this, QrSickbedList.class);
        startActivity(intent);
    }

    public void goNfcScanner(View view) {
//        System.out.println("goNfcScanner goNfcScanner goNfcScanner");
        Intent intent = new Intent(this, QrNfcActivity.class);
        startActivity(intent);
    }

    private boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state);
    }
}

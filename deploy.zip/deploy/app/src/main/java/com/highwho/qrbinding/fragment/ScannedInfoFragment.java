package com.highwho.qrbinding.fragment;

import android.app.Fragment;
import android.app.LoaderManager;
import android.content.AsyncTaskLoader;
import android.content.Intent;
import android.content.Loader;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.highwho.qrbinding.BR;
import com.highwho.qrbinding.R;
import com.highwho.qrbinding.datasource.DatabaseManager;
import com.highwho.qrbinding.datasource.repository.HospitalRepository;
import com.highwho.qrbinding.entity.HospitalEntity;
import com.highwho.qrbinding.entity.ScannedEntity;

/**
 * Created by xyz on 3/7/16.
 */
public class ScannedInfoFragment extends Fragment implements LoaderManager.LoaderCallbacks<HospitalEntity>{
    public static final String SCANNED_ENTITY_ARGUMENT_NAME = "scanned_entity";

    private HospitalRepository hospitalRepository;
    private Integer hospitalId;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ScannedEntity scannedEntity = new ScannedEntity();
        if(getArguments().containsKey(SCANNED_ENTITY_ARGUMENT_NAME)) {
            Parcelable parcelable = getArguments().getParcelable(SCANNED_ENTITY_ARGUMENT_NAME);
            if(parcelable instanceof ScannedEntity) {
                scannedEntity = (ScannedEntity)parcelable;
                hospitalId = scannedEntity.getHospitalId();
            }
        }
        ViewDataBinding binding = DataBindingUtil.inflate(inflater, R.layout.sickbed_info, container, false);
        binding.setVariable(BR.sEntity, scannedEntity);
        View view = binding.getRoot();
        upSetButton(view);

        hospitalRepository = new HospitalRepository(DatabaseManager.getWiseInstance(this.getActivity()));
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getLoaderManager().initLoader(0, null, this);
    }

    @Override
    public Loader<HospitalEntity> onCreateLoader(int id, Bundle args) {
        return createHospitalLoader();
    }

    @Override
    public void onLoadFinished(Loader<HospitalEntity> loader, HospitalEntity data) {
        if(data != null) {
            ((TextView)getView().findViewById(R.id.text_sickbed_hospital_name)).setText(data.getName());
        }
    }

    @Override
    public void onLoaderReset(Loader<HospitalEntity> loader) {
        if(getView() != null) {
            ((TextView) getView().findViewById(R.id.text_sickbed_hospital_name)).setText("");
        }
    }

    private AsyncTaskLoader<HospitalEntity> createHospitalLoader() {
        return new AsyncTaskLoader<HospitalEntity>(this.getActivity()) {
            @Override
            public HospitalEntity loadInBackground() {
                if(hospitalId != null && hospitalId > 0) {
                    return hospitalRepository.findById(hospitalId);
                }
                return null;
            }

            @Override
            protected void onStartLoading() {
                super.onStartLoading();
                forceLoad();
            }
        };
    }

    private void goToWeb() {
        if(getView() == null) return;
        View view = getView().findViewById(R.id.sickbed_code_text);
        if(view instanceof TextView) {
            TextView codeView = (TextView)view;
            Uri webpage = Uri.parse(String.format("http://%s/%s", getResources().getString(R.string.short_url_host), codeView.getText()));
            Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
            if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
                startActivity(intent);
            }
        }
    }

    private void upSetButton(View view) {
        view.findViewById(R.id.go_web_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToWeb();
            }
        });
    }
}

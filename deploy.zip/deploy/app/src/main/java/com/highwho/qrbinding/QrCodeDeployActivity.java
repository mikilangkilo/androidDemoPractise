package com.highwho.qrbinding;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import com.highwho.qrbinding.common.view.pager.FragmentPageInfo;
import com.highwho.qrbinding.entity.HospitalEntity;
import com.highwho.qrbinding.entity.ScannedEntity;
import com.highwho.qrbinding.fragment.HospitalsFragment;
import com.highwho.qrbinding.fragment.SettingFragment;
import com.highwho.qrbinding.fragment.ScannedInfoFragment;
import com.highwho.qrbinding.fragment.ScanOperFragment;
import com.highwho.qrbinding.fragment.SEntitiesFragment;
import com.highwho.qrbinding.fragment.ViewPagerFragment;
import com.highwho.qrbinding.services.SickbedFileOutputService;
import com.highwho.qrbinding.services.SickbedUploadService;

/**
 * Created by xyz on 2/29/16.
 */
public class QrCodeDeployActivity extends AppCompatActivity implements
        ScanOperFragment.OnSEntitySavedListener,
        HospitalsFragment.OnHospitalSelectListener,
        SEntitiesFragment.SickbedSelectionHandler {

    private ViewPagerFragment mPagerFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sickbed_deploy);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.main_toolbar);
        myToolbar.setTitle(R.string.action_bar_title);
        setSupportActionBar(myToolbar);
        if (savedInstanceState == null) {
            mPagerFragment = new ViewPagerFragment();
            getFragmentManager().beginTransaction().add(R.id.view_pager_fragment, mPagerFragment).commit();
        }
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
//        outState.putInt("tab", getActionBar().getSelectedNavigationIndex());
    }


    private void filterFragmentIntent(int requestCode, int resultCode, Intent data) {
        for (FragmentPageInfo info : mPagerFragment.getStripPageAdapter().getFragmentInfos()) {
            Fragment fragment = info.getCreatedFragment();
            if (fragment != null && fragment instanceof ScanOperFragment) {
                ((ScanOperFragment) fragment).filterIntent(requestCode, resultCode, data);
                break;
            }
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        filterFragmentIntent(requestCode, resultCode, data);
    }

    public void onNewIntent(Intent intent) {
        filterFragmentIntent(0, 0, intent);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_bar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.export_data_action:
                Intent intent = new Intent(this, SickbedFileOutputService.class);
                startService(intent);
                return true;
            case R.id.scan_nfc_action:
                goNfcScanner();
                return true;
            case R.id.user_login_action:
                loginServer();
                return true;
            case R.id.user_upload_sickbed_action:
                uploadSickbedsData();
                return true;
            case R.id.user_setting_action:
                getFragmentManager().beginTransaction()
                        .add(R.id.sickbed_info_fragment, new SettingFragment())
                        .addToBackStack(null)
                        .commit();
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //for toolbar action scan nfc
    private void goNfcScanner() {
        Intent intent = new Intent(this, QrNfcActivity.class);
        startActivity(intent);
    }

    private void loginServer() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("登录");
        final View view = getLayoutInflater().inflate(R.layout.login, null);
        builder.setView(view);

        builder.setPositiveButton("登录", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String name =
                        ((EditText) view.findViewById(R.id.edit_login_username))
                                .getText().toString();

                String password =
                        ((EditText) view.findViewById(R.id.edit_login_password))
                                .getText().toString();

                App.authenticManager(QrCodeDeployActivity.this)
                        .loginByDefault(name, password);
            }
        }).setNegativeButton("取消", null);
        builder.show();
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() > 0) {
            getFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onSelectedHospital(HospitalEntity entity, View view, int position) {
        boolean found = false;
        for (FragmentPageInfo info : mPagerFragment.getStripPageAdapter().getFragmentInfos()) {
            Fragment fragment = info.getCreatedFragment();
            if (fragment != null && fragment instanceof ScanOperFragment) {
                found = ((ScanOperFragment) fragment).onHospitalChange(entity);
                break;
            }
        }
        if(found) {
            mPagerFragment.getViewPager().setCurrentItem(1, true);
        }
        return found;
    }

    //callback from SEntitiesFragment
    @Override
    public void handleEntitySelected(View view, ScannedEntity scannedEntity) {
        Bundle bundle = new Bundle();
        bundle.putParcelable(ScannedInfoFragment.SCANNED_ENTITY_ARGUMENT_NAME, scannedEntity);
        ScannedInfoFragment scannedInfoFragment = new ScannedInfoFragment();
        scannedInfoFragment.setArguments(bundle);

        getFragmentManager().beginTransaction()
                .add(R.id.sickbed_info_fragment, scannedInfoFragment)
                .hide(getFragmentManager().findFragmentById(R.id.view_pager_fragment))
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onSickbedSaved(ScannedEntity scannedEntity) {

    }
    public void uploadSickbedsData() {
        Intent intent = new Intent(this, SickbedUploadService.class);
        startService(intent);
    }
}

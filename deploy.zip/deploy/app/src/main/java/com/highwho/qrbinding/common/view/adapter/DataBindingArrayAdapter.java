package com.highwho.qrbinding.common.view.adapter;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

/**
 * Created by xyz on 3/11/16.
 */
public abstract class DataBindingArrayAdapter<T, K> extends ArrayAdapter<T> {
    private K remarkKey;
    private final LayoutInflater mFlater;
    private final int mLayoutResource;
    protected int variable;

    public DataBindingArrayAdapter(Context context, int resource, int variable) {
        super(context, resource);
        this.variable = variable;
        mFlater = LayoutInflater.from(getContext());
        mLayoutResource = resource;
        Log.d("DataBindingArrayAdapter", "new init data binding array adapter");
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewDataBinding viewDataBinding;
        if(convertView == null) {
            viewDataBinding = DataBindingUtil.inflate(mFlater, mLayoutResource, parent, false);
        } else {
            viewDataBinding = DataBindingUtil.bind(convertView);
        }
        viewDataBinding.setVariable(variable, getItem(position));
        if(viewDataBinding.hasPendingBindings()) {
            viewDataBinding.executePendingBindings();
        }
        if(equalRemark(getRemarkKey(), position, getItem(position))) {
            onGetRemarkView(convertView, position);
        }
        return viewDataBinding.getRoot();
    }

    protected View onGetRemarkView(View view, int position) {
        return view;
    }

    public K getRemarkKey() {
        return remarkKey;
    }

    public void setRemarkKey(K remarkKey) {
        this.remarkKey = remarkKey;
    }

    protected abstract boolean equalRemark(K key, int position, T data);
}

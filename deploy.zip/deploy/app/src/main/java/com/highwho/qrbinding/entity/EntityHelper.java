package com.highwho.qrbinding.entity;

import android.content.ContentValues;
import android.database.Cursor;
import android.util.JsonWriter;
import android.util.Log;

import java.io.IOException;
import java.util.Date;

/**
 * Created by xyz on 6/16/16.
 */
public class EntityHelper {
    public static void writeSEntityToJson(ScannedEntity scannedEntity, JsonWriter writer) {
        try {
            writer.beginObject();
            writer.name("code").value(scannedEntity.getCode());
            writer.name("hid").value(scannedEntity.getHospitalId());
            writer.name("class").value(scannedEntity.getCategory());
            writer.name("name").value(scannedEntity.getName());

            writer.name("extra").value(scannedEntity.getExtraBed());
            if (scannedEntity.getNfcId() != null)
                writer.name("nfcid").value(scannedEntity.getNfcId());
            writer.name("modified").value(scannedEntity.getModifyDate().getTime());
            writer.name("division").value(scannedEntity.getDivision());
            if (scannedEntity.getRegion() != null)
                writer.name("region").value(scannedEntity.getRegion());
            if (scannedEntity.getFloor() != null)
                writer.name("floor").value(scannedEntity.getFloor());
            if (scannedEntity.getBuilding() != null)
                writer.name("building").value(scannedEntity.getBuilding());

            if (scannedEntity.getWardNumber() != null) {
                writer.name("ward").beginObject();
                if (scannedEntity.getWardCapacity() != 0) {
                    writer.name("capacity").value(scannedEntity.getWardCapacity());
                    writer.name("gender").value(scannedEntity.getWardGender());
                    writer.name("number").value(scannedEntity.getWardNumber());
                }
                writer.endObject();
            }

            writer.endObject();
            writer.flush();
        } catch (IOException | NullPointerException e) {
            Log.e(EntityHelper.class.getSimpleName(), "toJsonObject", e);
        } /*finally {
            if (writer != null) try {
                writer.close();
            } catch (IOException e) {
                Log.e(EntityHelper.class.getSimpleName(), "toJsonObject.close", e);
            }
        }*/
    }

    public static ScannedEntity mapCursorToSEntity(Cursor cursor) {
        int columnIndex = -1;
        ScannedEntity scannedEntity = new ScannedEntity();
        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema._ID);
        if (columnIndex >= 0) {
            scannedEntity.setCode(cursor.getString(columnIndex));
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_ENTITY_CLASS);
        if (columnIndex >= 0) {
            scannedEntity.setCategory(cursor.getString(columnIndex));
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_ENTITY_NAME);
        if (columnIndex >= 0) {
            scannedEntity.setName(cursor.getString(columnIndex));
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_BED_EXTRA);
        if (columnIndex >= 0) {
            scannedEntity.setExtraBed(cursor.getInt(columnIndex) > 0);
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_DIVISION);
        if (columnIndex >= 0) {
            scannedEntity.setDivision(cursor.getInt(columnIndex));
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_REGION);
        if (columnIndex >= 0) {
            scannedEntity.setRegion(cursor.getString(columnIndex));
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_FLOOR);
        if (columnIndex >= 0) {
            scannedEntity.setFloor(cursor.getString(columnIndex));
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_BUILDING);
        if (columnIndex >= 0) {
            scannedEntity.setBuilding(cursor.getString(columnIndex));
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_WARD_NUMBER);
        if (columnIndex >= 0) {
            scannedEntity.setWardNumber(cursor.getString(columnIndex));
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_WARD_CAPACITY);
        if (columnIndex >= 0) {
            scannedEntity.setWardCapacity(cursor.getInt(columnIndex));
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_WARD_GENDER);
        if (columnIndex >= 0) {
            scannedEntity.setWardGender(cursor.getInt(columnIndex));
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_NFC_ID);
        if (columnIndex >= 0) {
            scannedEntity.setNfcId(cursor.getString(columnIndex));
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_HID);
        if (columnIndex >= 0) {
            scannedEntity.setHospitalId(cursor.getInt(columnIndex));
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_MODIFY_SYNCED);
        if (columnIndex >= 0) {
            scannedEntity.setSynced(cursor.getInt(columnIndex) > 0);
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_CREATE_TIME);
        if (columnIndex >= 0) {
            scannedEntity.setCreateDate(new Date(cursor.getLong(columnIndex)));
        }

        columnIndex = cursor.getColumnIndex(ScannedEntity.Schema.COLUMN_MODIFY_TIME);
        if (columnIndex >= 0) {
            scannedEntity.setModifyDate(new Date(cursor.getLong(columnIndex)));
        }

        return scannedEntity;
    }

    public static ContentValues sEntityToContentValues(ScannedEntity entity) {
        ContentValues contentValues = new ContentValues(12);

        if (entity.getCode() != null) contentValues.put(ScannedEntity.Schema._ID, entity.getCode());

        if (entity.getCategory() != null) contentValues.put(ScannedEntity.Schema.COLUMN_ENTITY_CLASS, entity.getCategory());

        if (entity.getName() != null)
            contentValues.put(ScannedEntity.Schema.COLUMN_ENTITY_NAME, entity.getName());

        if (entity.getExtraBed() != null)
            contentValues.put(ScannedEntity.Schema.COLUMN_BED_EXTRA, entity.getExtraBed());

        if (entity.getDivision() != null)
            contentValues.put(ScannedEntity.Schema.COLUMN_DIVISION, entity.getDivision());
        if (entity.getHospitalId() != null)
            contentValues.put(ScannedEntity.Schema.COLUMN_HID, entity.getHospitalId());
        if (entity.getRegion() != null)
            contentValues.put(ScannedEntity.Schema.COLUMN_REGION, entity.getRegion());
        if (entity.getBuilding() != null)
            contentValues.put(ScannedEntity.Schema.COLUMN_BUILDING, entity.getBuilding());
        if (entity.getFloor() != null)
            contentValues.put(ScannedEntity.Schema.COLUMN_FLOOR, entity.getFloor());

        if (entity.getWardNumber() != null)
            contentValues.put(ScannedEntity.Schema.COLUMN_WARD_NUMBER, entity.getWardNumber());

        contentValues.put(ScannedEntity.Schema.COLUMN_WARD_CAPACITY, entity.getWardCapacity());
        contentValues.put(ScannedEntity.Schema.COLUMN_WARD_GENDER, entity.getWardGender());

        if (entity.getWardNumber() != null)
            contentValues.put(ScannedEntity.Schema.COLUMN_WARD_NUMBER, entity.getWardNumber());

        if (entity.getNfcId() != null)
            contentValues.put(ScannedEntity.Schema.COLUMN_NFC_ID, entity.getNfcId());
        contentValues.put(ScannedEntity.Schema.COLUMN_MODIFY_SYNCED, 0);
        contentValues.put(ScannedEntity.Schema.COLUMN_MODIFY_TIME, new Date().getTime());
        return contentValues;
    }

    public static ContentValues divisionToContentValues(DivisionEntity division) {
        ContentValues contentValues = new ContentValues(12);
        if (division.getId() != null) contentValues.put(DivisionEntity.Schema._ID, division.getId());
        if (division.getName() != null) contentValues.put(DivisionEntity.Schema.COLUMN_NAME, division.getName());
        if (division.getHospitalId() != null) contentValues.put(DivisionEntity.Schema.COLUMN_HOSPITAL_ID, division.getHospitalId());
        return contentValues;
    }



}

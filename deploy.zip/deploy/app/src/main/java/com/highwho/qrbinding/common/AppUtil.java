package com.highwho.qrbinding.common;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by xyz on 3/12/16.
 */
public class AppUtil {
    public static void showError(Context context, String prompt, Exception e) {
        Toast.makeText(context, String.format("%s:%s", prompt, e.getLocalizedMessage()), Toast.LENGTH_LONG).show();
    }

}

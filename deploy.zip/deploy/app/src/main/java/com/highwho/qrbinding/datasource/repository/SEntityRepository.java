package com.highwho.qrbinding.datasource.repository;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.highwho.qrbinding.datasource.DatabaseManager;
import com.highwho.qrbinding.entity.EntityHelper;
import com.highwho.qrbinding.entity.ScannedEntity;

import java.util.List;

/**
 * Created by xyz on 3/13/16.
 */
public class SEntityRepository extends Repository<ScannedEntity, String> {

    public SEntityRepository(DatabaseManager databaseManager) {
        super(databaseManager);
    }

    @Override
    protected String getTableName() {
        return ScannedEntity.Schema.TABLE_NAME;
    }

    @Override
    protected ScannedEntity mapRecordToEntity(Cursor cursor) {
        return EntityHelper.mapCursorToSEntity(cursor);
    }

    @Override
    protected String getIdFieldName() {
        return ScannedEntity.Schema._ID;
    }

    @Override
    public ScannedEntity save(ScannedEntity entity) {
        ContentValues contentValues = EntityHelper.sEntityToContentValues(entity);
        long rowId = database.insertWithOnConflict(getTableName(), null, contentValues, SQLiteDatabase.CONFLICT_REPLACE);
        if (rowId < 0) {
            throw new RuntimeException("insert row id:" + rowId);
        }
        return entity;
    }

    public List<ScannedEntity> findUnSynced() {
        try (Cursor cursor = database.query(
                getTableName(),
                new String[]{"*"},
                ScannedEntity.Schema.COLUMN_MODIFY_SYNCED + "=?", new String[]{"0"},
                null, null, null)) {
            return toDataList(cursor);
        }
    }

    public boolean updateModify(long modifyTime, String code) {
        ContentValues contentValues = new ContentValues(1);
        contentValues.put(ScannedEntity.Schema.COLUMN_MODIFY_SYNCED, 1);
        long row = database.update(
                ScannedEntity.Schema.TABLE_NAME,
                contentValues,
                String.format(" %s=? and %s <= ?", ScannedEntity.Schema._ID, ScannedEntity.Schema.COLUMN_MODIFY_TIME),
                new String[]{code, String.valueOf(modifyTime)}
        );
        return row == 1;
    }
}

package com.highwho.qrbinding.fragment;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.highwho.qrbinding.R;
import com.highwho.qrbinding.common.view.pager.StripPageAdapter;

/**
 * Created by xyz on 3/15/16.
 */
public class ViewPagerFragment extends Fragment{

    private ViewPager mViewPager;
    private StripPageAdapter mStripPageAdapter;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.view_pager, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(getView() != null) {
            mViewPager = (ViewPager)getView().findViewById(R.id.page_view);
            setUpViewPager(savedInstanceState);
        }

    }

    private void setUpViewPager(Bundle savedInstanceState) {
        mStripPageAdapter = new StripPageAdapter(this.getActivity());

        mStripPageAdapter.addFragmentPage(
                SEntitiesFragment.class.getName(), "已有数据", null);

        mStripPageAdapter.addFragmentPage(
                ScanOperFragment.class.getName(), "操作病床", null);

        mStripPageAdapter.addFragmentPage(
                HospitalsFragment.class.getName(), "医院选择", null);

        mViewPager.setOffscreenPageLimit(3);
        mViewPager.setAdapter(mStripPageAdapter);
        mViewPager.setCurrentItem(0);
    }

    public StripPageAdapter getStripPageAdapter() {
        return mStripPageAdapter;
    }

    public ViewPager getViewPager() {
        return mViewPager;
    }
}

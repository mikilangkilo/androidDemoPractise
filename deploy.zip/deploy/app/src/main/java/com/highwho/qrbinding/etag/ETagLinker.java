package com.highwho.qrbinding.etag;

/**
 * Created by xyz on 3/3/16.
 */
public abstract class ETagLinker<E extends ETag, T> {
    protected TagDataExtractor<E, T> extractor;

    public abstract void linkTo(E eTag);

    public ETagLinker(TagDataExtractor<E, T> extractor) {
        this.extractor = extractor;
    }
}

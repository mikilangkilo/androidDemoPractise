package com.highwho.qrbinding.common.view;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

public abstract class EndlessScrollListener extends RecyclerView.OnScrollListener /*implements View.OnScrollChangeListener*/ {
    // The minimum amount of items to have below your current scroll position
    // before loading more.
    private int visibleThreshold = 5;
//    private int previousTotalItemCount = 0;

    private LinearLayoutManager mLinearLayoutManager;

    public EndlessScrollListener(LinearLayoutManager layoutManager) {
        this.mLinearLayoutManager = layoutManager;
    }

    public EndlessScrollListener(int visibleThreshold, LinearLayoutManager mLinearLayoutManager) {
        this.visibleThreshold = visibleThreshold;
        this.mLinearLayoutManager = mLinearLayoutManager;
    }

    //    @Override
    public void onScrollChange(View view, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
        if (view instanceof RecyclerView) {
            this.onScrolled((RecyclerView) view, scrollX, scrollY);
        }
    }

    // This happens many times a second during a scroll, so be wary of the code you place here.
    // We are given a few useful parameters to help us work out if we need to load some more data,
    // but first we check if we are waiting for the previous load to finish.
    @Override
    public void onScrolled(RecyclerView view, int dx, int dy) {
        int firstVisibleItem = mLinearLayoutManager.findFirstVisibleItemPosition();
        int visibleItemCount = view.getChildCount();
        int totalItemCount = mLinearLayoutManager.getItemCount();
        // If the total item count is zero and the previous isn't, assume the
        // list is invalidated and should be reset back to initial state
//        if (totalItemCount < previousTotalItemCount) {
//            this.previousTotalItemCount = totalItemCount;
//        }

        // If it’s still loading, we check to see if the dataset count has
        // changed, if so we conclude it has finished loading and update the current page
        // number and total item count.
//        if (totalItemCount > previousTotalItemCount) {
//            previousTotalItemCount = totalItemCount;
//        }

        // If it isn’t currently loading, we check to see if we have breached
        // the visibleThreshold and need to reload more data.
        // If we do need to reload some more data, we execute onLoadMore to fetch the data.
        if ((firstVisibleItem + visibleItemCount + visibleThreshold) >= totalItemCount) {
            onLoadMore(totalItemCount, true);
        }
    }

    // Defines the process for actually loading more data based on page
    public abstract void onLoadMore(int totalItemsCount, boolean toBottom);
}
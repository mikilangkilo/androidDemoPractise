package com.highwho.qrbinding;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.highwho.qrbinding.entity.ScannedEntity;
import com.highwho.qrbinding.fragment.ScannedInfoFragment;
import com.highwho.qrbinding.fragment.SEntitiesFragment;

/**
 * Created by xyz on 3/6/16.
 */
public class ListMainActivity extends AppCompatActivity implements SEntitiesFragment.SickbedSelectionHandler{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_sickbeds);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.main_toolbar);
        myToolbar.setTitle(R.string.action_bar_title);
        setSupportActionBar(myToolbar);

        if(savedInstanceState == null) {
            getFragmentManager().beginTransaction().add(R.id.sickbed_list_fragment, new SEntitiesFragment()).commit();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_bar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.export_data_action:
                // to do
                return true;
            case R.id.scan_nfc_action:
                goNfcScanner();
                return true;
//            case R.id.sickbed_deploy_action:
//                goSickbedDeploy();
//                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //callback from SickbedFragment
    @Override
    public void handleEntitySelected(View view, ScannedEntity scannedEntity) {
        Bundle bundle = new Bundle();
        bundle.putParcelable(ScannedInfoFragment.SCANNED_ENTITY_ARGUMENT_NAME, scannedEntity);
        ScannedInfoFragment scannedInfoFragment = new ScannedInfoFragment();
        scannedInfoFragment.setArguments(bundle);

        getFragmentManager().beginTransaction()
                .add(R.id.sickbed_info_fragment, scannedInfoFragment)
                .hide(getFragmentManager().findFragmentById(R.id.sickbed_list_fragment))
                .addToBackStack(null).commitAllowingStateLoss();
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() > 0 ){
            getFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    private void goNfcScanner() {
        Intent intent = new Intent(this, QrNfcActivity.class);
        startActivity(intent);
    }

    private void goSickbedDeploy() {
        Intent intent = new Intent(this, QrCodeDeployActivity.class);
        startActivity(intent);
    }

}

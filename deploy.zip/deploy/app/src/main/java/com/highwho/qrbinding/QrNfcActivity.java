package com.highwho.qrbinding;

import android.app.Activity;
import android.content.Intent;
import android.database.SQLException;
import android.graphics.Color;
import android.net.Uri;
import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.highwho.qrbinding.datasource.HisDbHelper;
import com.highwho.qrbinding.nfc.SickbedTagException;
import com.highwho.qrbinding.nfc.SickbedTagManager;


/**
 * Created by xyz on 2/27/16.
 */
public class QrNfcActivity extends AppCompatActivity {
    private SickbedTagManager sickbedTagManager;
    private Uri qrCodeurl;
    private HisDbHelper hisDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qr_nfc_binding);
        ((Switch) findViewById(R.id.switch_auto_write)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Switch switchView = ((Switch) findViewById(R.id.switch_read_verify));
                if (isChecked) {
                    switchView.setChecked(false);
                    switchView.setEnabled(false);
                } else {
                    switchView.setEnabled(true);
                }
            }
        });
        sickbedTagManager = SickbedTagManager.createManager(this);
        hisDbHelper = new HisDbHelper(this.getApplication());
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
    }

    public void onPause() {
        super.onPause();
        sickbedTagManager.stopListener();
    }

    public void onResume() {
        super.onResume();
        sickbedTagManager.startListener();
    }

    public void onNewIntent(Intent intent) {
        String writeUrl = null;

        final boolean isWrite = isAutoWrite();
        final Activity context = this;

        SickbedTagManager.SickbedTagCallBack callBack = new SickbedTagManager.SickbedTagCallBack() {
            @Override
            public void onFilterCallback(Uri uri, String code, SickbedTagException e, String nfcId) {
                String result = "none content";
                int level = 1;

                if(e == null && code == null) {
                    e = new SickbedTagException("code不存在");
                }

                if (e == null) {
                    if (isWrite) {
                        setTextContent(R.id.text_qr_code, "已写入", 0);
                        result = code;
                        qrCodeurl = null;
                    } else {
                        result = code;
                        if (isVerifing()) {
                            if (qrCodeurl == null) {
                                result = "二维码数据为空";
                                level = 3;
                            } else if (!qrCodeurl.getLastPathSegment().equals(result)) {
                                result = "验证失败:" + result;
                                level = 3;
                            } else if (!QrNfcActivity.this.isChecked(result)) {
                                result = "已验证过当前二维码:" + QrNfcActivity.this.hisDbHelper.findCheckCodeTime(result);
                                level = 3;
                            } else {
                                result = "验证成功";
                            }
                        }
                    }
                } else {
                    e.printStackTrace();
                    result = e.getMessage();
                    level = 3;
                }
                if (result != null && result.length() > 0) {
                    setTextContent(R.id.text_nfc_code, result, level);
                } else {
                    setTextContent(R.id.text_nfc_code, "内容为空", 2);
                }

                if (isContinueWorking() && level < 3) {
                    scanQrCode(null);
                }
            }
        };

        if (isWrite && qrCodeurl != null) {
            writeUrl = qrCodeurl.toString();
            sickbedTagManager.filterAndWrite(intent, writeUrl, isWriteOverride(), null, callBack);
        } else if (!isWrite) {
            sickbedTagManager.filter(intent, callBack);
        } else {
            setTextContent(R.id.text_nfc_code, "二维码为空", 3);
        }

    }

    private boolean isChecked(String code) {
        try {
            this.hisDbHelper.insertCheckCode(code);
            Log.i("isChecked", "check success");
            return true;
        } catch (SQLException e) {
            Log.i("isChecked", "check failed");
            return false;
        }
    }

    public void scanQrCode(View view) {
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setOrientationLocked(false);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
        integrator.setCaptureActivity(QrCaptureActivity.class);
        integrator.setPrompt("请扫描二维码");
        integrator.initiateScan();
    }

    public boolean isAutoWrite() {
        return ((Switch) findViewById(R.id.switch_auto_write)).isChecked();
    }

    public boolean isContinueWorking() {
        return ((Switch) findViewById(R.id.switch_continue_working)).isChecked();
    }

    public boolean isWriteOverride() {
        return ((Switch) findViewById(R.id.switch_write_override)).isChecked();
    }

    public boolean isVerifing() {
        return ((Switch) findViewById(R.id.switch_read_verify)).isChecked();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                Toast.makeText(this, "扫描取消", Toast.LENGTH_SHORT).show();
            } else {
                qrCodeurl = Uri.parse(result.getContents());
                if (qrCodeurl != null && qrCodeurl.getHost().contains("w-se.cn")) {
                    String code = qrCodeurl.getLastPathSegment();
                    setTextContent(R.id.text_qr_code, code, 0);
                } else {
                    setTextContent(R.id.text_qr_code, "无正确内容", 3);
                }
            }

        }
    }

    private void setTextContent(int id, String content, int messageLevel) {
        TextView textView = (TextView) findViewById(id);
        textView.setText(content);
        switch (messageLevel) {
            case 1:
                textView.setTextColor(Color.GREEN);
                break;
            case 2:
                textView.setTextColor(Color.YELLOW);
                break;
            case 3:
                textView.setTextColor(Color.RED);
                break;
            default:
                textView.setTextColor(Color.BLACK);
        }

    }


    private String idToString(byte[] id) {
        String str = new String();
        for (int i = 0; i < id.length; i++) {
            str += String.format(":%02X", id[i]);
        }
        return str.isEmpty() ? "" : str.substring(1);
    }

}

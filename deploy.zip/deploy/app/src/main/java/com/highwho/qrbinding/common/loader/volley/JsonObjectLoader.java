package com.highwho.qrbinding.common.loader.volley;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;

import org.json.JSONObject;

/**
 * Created by xyz on 3/12/16.
 */
public abstract class JsonObjectLoader<D> extends JsonLoader<D, JSONObject, JsonObjectRequest> {

    public JsonObjectLoader(Context context, RequestQueue requestQueue) {
        super(context, requestQueue);
    }

    public JsonObjectLoader(Context context) {
        super(context);
    }

}

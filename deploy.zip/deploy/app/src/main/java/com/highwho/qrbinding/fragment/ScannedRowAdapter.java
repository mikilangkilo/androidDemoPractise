package com.highwho.qrbinding.fragment;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.highwho.qrbinding.BR;
import com.highwho.qrbinding.R;
import com.highwho.qrbinding.common.view.MutableRecyclerAdapter;
import com.highwho.qrbinding.entity.ScannedEntity;

import java.util.List;

/**
 * Created by xyz on 3/4/16.
 */
public class ScannedRowAdapter extends MutableRecyclerAdapter<View, ScannedEntity>{
    private Activity activity;

    public ScannedRowAdapter(List<ScannedEntity> data, Activity activity) {
        super(data);
        this.activity = activity;
    }

    public ScannedRowAdapter(Activity activity) {
        this.activity = activity;
    }

    @Override
    protected View createView(ViewGroup parent, int viewType) {
        return LayoutInflater.from(parent.getContext()).inflate(R.layout.sickbed_info_row, parent, false);
    }


    @Override
    public void onBindViewHolder(ViewHolder<View> holder, int position) {
        View view = holder.binderData(getData().get(position), BR.sEntity);
        if(view == null) {
            Log.e("onBindViewHolder", String.format("position %d view is null", position));
        }
    }


}

package com.highwho.qrbinding.business;

import android.os.AsyncTask;
import android.util.Log;

import com.highwho.qrbinding.datasource.DatabaseManager;
import com.highwho.qrbinding.datasource.repository.HospitalRepository;
import com.highwho.qrbinding.datasource.repository.SEntityRepository;
import com.highwho.qrbinding.entity.HospitalEntity;
import com.highwho.qrbinding.entity.ScannedEntity;
import com.highwho.qrbinding.etag.ETag;
import com.highwho.qrbinding.etag.ETagException;
import com.highwho.qrbinding.etag.WiseCodeExtractor;
import com.highwho.qrbinding.etag.nfc.NfcTag;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by xyz on 3/14/16.
 */
public class SEntityOperationHandler {
    public static final int CALLBACK_LEVEL_ERROR = -2;
    public static final int CALLBACK_LEVEL_WARNING = -1;
    public static final int CALLBACK_LEVEL_DEFAULT = 0;
    public static final int CALLBACK_LEVEL_INFO = 1;
    public static final int CALLBACK_LEVEL_SUCCESS = 2;

    public static final int NUMBER_AUTO_CLOSE = 0;
    public static final int NUMBER_AUTO_ADD = 1;
    public static final int NUMBER_AUTO_SUB = 2;


    public interface OperationListener {
        void onSavedSickbed(CallbackArguments arguments);

        void onDetectSickbed(CallbackArguments arguments);
    }

    private SEntityRepository sEntityRepository;
    private HospitalRepository hospitalRepository;

    private AsyncTask<String, ?, CallbackArguments> currentTask;

    private WeakReference<OperationListener> listener;

    public SEntityOperationHandler(OperationListener listener, DatabaseManager databaseManager) {
        this.listener = new WeakReference<>(listener);
        this.sEntityRepository = new SEntityRepository(databaseManager);
        this.hospitalRepository = new HospitalRepository(databaseManager);
    }

    //call in the UI thread
    public boolean saveSickbed(ScannedEntity entity) {
        Log.d(this.getClass().getSimpleName(), "saveSickbed started");
        if (currentTask != null && !currentTask.getStatus().equals(AsyncTask.Status.FINISHED)) {
            Log.d(this.getClass().getSimpleName(), "saveSickbed return false");
            return false;
        }
        currentTask = new SaveSickbedTask(entity);
        currentTask.execute();
        return true;
    }

    //call in the UI thread
    public <E extends ETag> boolean detectedETag(WiseCodeExtractor<E> extractor, E eTag, int autoUpdate, ScannedEntity entity) {
        Log.d(this.getClass().getSimpleName(), "saveSickbed started");
        if (currentTask != null && !currentTask.getStatus().equals(AsyncTask.Status.FINISHED)) {
            Log.d(this.getClass().getSimpleName(), "saveSickbed return false");
            return false;
        }
        currentTask = new DetectETagTask<>(extractor, eTag, autoUpdate, entity);
        currentTask.execute();
        return true;
    }

    private ScannedEntity initNewSickbedEntity(String code, ScannedEntity old, int autoState, CallbackArguments arguments) {
        ScannedEntity scannedEntity = new ScannedEntity();
        scannedEntity.setCreateDate(new Date());
        if (old == null) {
            return scannedEntity;
        }
        scannedEntity.setCode(code);
        scannedEntity.setCategory(old.getCategory());
        scannedEntity.setRegion(old.getRegion());
        scannedEntity.setDivision(old.getDivision());
        scannedEntity.setHospitalId(old.getHospitalId());
        scannedEntity.setHospital(old.getHospital());

        //add for new sickbed items
        scannedEntity.setBuilding(old.getBuilding());
        scannedEntity.setFloor(old.getFloor());
        scannedEntity.setWardNumber(old.getWardNumber());
        scannedEntity.setWardCapacity(old.getWardCapacity());
        scannedEntity.setWardGender(old.getWardGender());

        String number = old.getName();
        try {
            number = updateNewNumber(old.getName(), autoState);
        } catch (IOException e) {
            arguments.detail = "自动添加失败";
        } finally {
            scannedEntity.setName(number);
        }
        return scannedEntity;
    }

    private String updateNewNumber(String bedNumber, int autoState) throws IOException {
        if (autoState == NUMBER_AUTO_CLOSE || bedNumber == null) {
            return bedNumber;
        }
        String ret = bedNumber;
        Pattern pattern = Pattern.compile("\\d+");

        Matcher matcher = pattern.matcher(bedNumber);
        boolean found = matcher.find();
        int start = -1;
        int end = -1;
        String group = null;
        while (found) {
            start = matcher.start();
            end = matcher.end();
            group = matcher.group();
            found = matcher.find();
        }
        if (group != null) {
            int num = Integer.parseInt(group);
            if (autoState == NUMBER_AUTO_ADD) {
                ++num;
            } else if (autoState == NUMBER_AUTO_SUB) {
                --num;
            }
            StringBuilder builder = new StringBuilder(bedNumber.length());
            if (start > 0) {
                Log.i("bedNumber.substring", bedNumber.substring(0, start));
                builder.append(bedNumber.substring(0, start));
            }

            builder.append(String.format("%0" + group.length() + "d", num));
            if (end < bedNumber.length()) {
                builder.append(bedNumber.substring(end));
            }
            ret = builder.toString();
        }
        return ret;
    }

    private class SaveSickbedTask extends AsyncTask<String, Void, CallbackArguments> {
        private ScannedEntity entity;

        public SaveSickbedTask(ScannedEntity entity) {
            this.entity = entity;
        }

        @Override
        protected CallbackArguments doInBackground(String... params) {
            CallbackArguments callbackArguments = new CallbackArguments();
            try {
                callbackArguments.prompt = "保存病床成功";
                callbackArguments.callbackLevel = CALLBACK_LEVEL_SUCCESS;
                if (entity.getHospitalId() == null || entity.getHospitalId() < 0 ) {
                    throw new Exception("医院没有选择");
                }
                if (entity.getCode() == null || entity.getCode().length() == 0) {
                    throw new Exception("二维码为空");
                }

                if (entity.getDivision() == null || entity.getDivision() == 0) {
                    throw new Exception("科室为空");
                }

                callbackArguments.scannedEntity = sEntityRepository.save(entity);
            } catch (Exception e) {
                e.printStackTrace();
                callbackArguments.detail = e.getMessage();
                callbackArguments.prompt = "保存失败:" + e.getMessage();
                callbackArguments.callbackLevel = CALLBACK_LEVEL_ERROR;
            }
            return callbackArguments;
        }

        @Override
        protected void onPostExecute(CallbackArguments arguments) {
            if (listener.get() != null) {
                listener.get().onSavedSickbed(arguments);
            }
        }
    }

    private class DetectETagTask<E extends ETag> extends AsyncTask<String, Void, CallbackArguments> {
        private static final String PROMPT_ARGUMENT_ERROR = "错误的电子标签";
        private WiseCodeExtractor<E> extractor;
        private E eTag;
        private int autoUpdate;
        private ScannedEntity currentEntity;

        public DetectETagTask(WiseCodeExtractor<E> extractor, E eTag, int autoUpdate, ScannedEntity entity) {
            super();
            this.extractor = extractor;
            this.eTag = eTag;
            this.autoUpdate = autoUpdate;
            this.currentEntity = entity;
        }

        private String getNfcId() throws ETagException {
            String nfcId = null;
            if (eTag != null && eTag instanceof NfcTag) {
                nfcId = extractor.getKey(eTag);
                if (nfcId == null) throw new ETagException("nfc tag id is null");
            }
            return nfcId;
        }

        private CallbackArguments onWiseCodeDetected(CallbackArguments arguments) throws ETagException, RuntimeException {
            String code = extractor.extract(eTag);
            if (code == null) throw new ETagException("code is null");

            int level = CALLBACK_LEVEL_DEFAULT;
            String prompt = "无内容";
            String nfcId = getNfcId();
            ScannedEntity entity = getSickbedByCode(code);
            if (entity == null) {
                prompt = "发现新的二维码";
                level = CALLBACK_LEVEL_INFO;
                entity = initNewSickbedEntity(code, currentEntity, autoUpdate, arguments);
                entity.setNfcId(nfcId);
            } else {
                prompt = "二维码已经存在";
                level = CALLBACK_LEVEL_WARNING;
                if (nfcId != null && !nfcId.equals(entity.getNfcId())) {
                    prompt += "- nfc id 不一致";
                    entity.setNfcId(nfcId);
                }
            }

            arguments.scannedEntity = entity;
            arguments.prompt = prompt;
            arguments.callbackLevel = level;
            return arguments;
        }

        private ScannedEntity getSickbedByCode(String code) {
            ScannedEntity entity = sEntityRepository.findById(code);
            Integer hid = entity != null ? entity.getHospitalId() : null;
            if (hid != null) {
                HospitalEntity hospitalEntity = hospitalRepository.findById(hid);
                entity.setHospital(hospitalEntity);
            }
            return entity;
        }

        @Override
        protected CallbackArguments doInBackground(String... params) {
            CallbackArguments arguments = new CallbackArguments();
            try {
                arguments = onWiseCodeDetected(arguments);
            } catch (ETagException | RuntimeException e) {
                arguments.detail = e.getMessage();
                arguments.prompt = PROMPT_ARGUMENT_ERROR;
                arguments.callbackLevel = CALLBACK_LEVEL_WARNING;
                Log.e(DetectETagTask.class.getSimpleName(), "onWiseCodeDetected", e);
            }
            return arguments;
        }

        @Override
        protected void onPostExecute(CallbackArguments callbackArguments) {
            if (listener.get() != null) {
                listener.get().onDetectSickbed(callbackArguments);
            }
        }
    }


    public class CallbackArguments {
        private String detail = null;
        private String prompt = "";
        private int callbackLevel = CALLBACK_LEVEL_INFO;
        private ScannedEntity scannedEntity = null;

        public CallbackArguments() {
        }

        public String getDetail() {
            return detail;
        }

        public String getPrompt() {
            return prompt;
        }

        public int getCallbackLevel() {
            return callbackLevel;
        }

        public ScannedEntity getScannedEntity() {
            return scannedEntity;
        }
    }

    public void stop() {
        if (currentTask != null) {
//            currentTask.cancel(true);
        }
        if (sEntityRepository != null) {
            sEntityRepository.close();
        }
    }

}

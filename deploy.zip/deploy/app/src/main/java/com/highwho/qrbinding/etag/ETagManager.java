package com.highwho.qrbinding.etag;

import android.app.Activity;
import android.net.Uri;
import android.nfc.NfcAdapter;

import com.highwho.qrbinding.etag.barcode.BarCodeDetector;
import com.highwho.qrbinding.etag.barcode.BarCodeTag;
import com.highwho.qrbinding.etag.barcode.BarCodeUriExtractor;
import com.highwho.qrbinding.etag.nfc.NdefUriExtractor;
import com.highwho.qrbinding.etag.nfc.NfcTag;
import com.highwho.qrbinding.etag.nfc.NfcTagDetector;

/**
 * Created by xyz on 3/3/16.
 */
public class ETagManager {
    private Activity activity;

    public ETagManager(Activity activity) {
        this.activity = activity;
    }

    public NfcTagDetector getNfcDetector() {
        NfcAdapter nfcAdapter = NfcAdapter.getDefaultAdapter(activity);
        return new NfcTagDetector(nfcAdapter, activity);
    }

    public BarCodeDetector getBarCodeDetector() {
        return new BarCodeDetector(activity);
    }

    public <E extends ETag> WiseCodeExtractor<E> getWiseCodeExtractor(TagDataExtractor<E, Uri> uriTagDataExtractor) {
        return new WiseCodeExtractor<E>(uriTagDataExtractor) {
            @Override
            public String getKey(E eTag) throws ETagException {
                return this.tagDataExtractor.getKey(eTag);
            }
        };
    }

    public WiseCodeExtractor<NfcTag> getWiseNfcExtractor() {
        return getWiseCodeExtractor(new NdefUriExtractor());
    }

    public WiseCodeExtractor<BarCodeTag> getWiseBarcodeExtractor() {
        return getWiseCodeExtractor(new BarCodeUriExtractor());
    }
}

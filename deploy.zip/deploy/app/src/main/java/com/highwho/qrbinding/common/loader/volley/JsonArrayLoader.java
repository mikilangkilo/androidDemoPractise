package com.highwho.qrbinding.common.loader.volley;

import android.content.Context;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xyz on 3/11/16.
 */
public abstract class JsonArrayLoader<T> extends JsonLoader<List<T>, JSONArray, JsonArrayRequest> {

    public JsonArrayLoader(Context context, RequestQueue requestQueue) {
        super(context, requestQueue);
    }

    public JsonArrayLoader(Context context) {
        super(context);
    }

    protected abstract T mapArrayItemToData(JSONArray jsonArray, int index);

    @Override
    protected List<T> mapJsonToData(JSONArray jsonArray) throws VolleyLoaderException{
        List<T> results = new ArrayList<>(jsonArray.length());
        VolleyLoaderException exception = null;
        for(int i =0; i < jsonArray.length();i++) {
            try {
                T object = this.mapArrayItemToData(jsonArray, i);
                results.add(object);
            } catch (Exception e) {
                exception = new VolleyLoaderException(e);
            }
        }
        if(exception != null) throw exception;
        return results;
    }



}

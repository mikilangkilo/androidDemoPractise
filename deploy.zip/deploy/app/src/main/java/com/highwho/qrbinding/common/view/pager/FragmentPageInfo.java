package com.highwho.qrbinding.common.view.pager;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

/**
 * Created by xyz on 3/9/16.
 */
public class FragmentPageInfo {
    private String name;
    private String title;
    private Bundle bundle;
    private Fragment fragment;


    public FragmentPageInfo(String name, String title, Bundle bundle) {
        this.name = name;
        this.title = title;
        this.bundle = bundle;
    }

    public String getName() {
        return name;
    }

    public String getTitle() {
        return title;
    }

    public Bundle getBundle() {
        return bundle;
    }

    //call on the main thread
    public Fragment fetchFragment(Context context) {
        if(fragment == null) {
            Log.d("fetchFragment","fetchFragment with " + name);
            fragment = Fragment.instantiate(context, name, bundle);
        }
        return fragment;
    }

    public Fragment getCreatedFragment() {
        return fragment;
    }

    //call on the main thread
    public void clearFragment() {
        this.fragment = null;
    }


}

package com.highwho.qrbinding.common.http;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import com.highwho.qrbinding.App;

import java.net.CookieStore;
import java.net.HttpCookie;
import java.net.URI;
import java.util.List;

/**
 * Created by xyz on 3/16/16.
 */
public class WiseCookieStore implements CookieStore {
    private static final String PREFERENCE_AUTHENTIC_NAME = "AUTHENTIC";
    private static final String PREFERENCE_COOKIE_NAME = "AUTHENTIC";
    private static final String COOKIE_SESSION_NAME = "HIS-SESSION";

    private App app;
    private CookieStore store;
    private SharedPreferences preferences;

    public WiseCookieStore(CookieStore store, App app) {
        this.store = store != null ? store : new MemmoryCookieStore();
        this.app = app;
        preferences = app.getContext().getApplicationContext().getSharedPreferences(PREFERENCE_AUTHENTIC_NAME, Context.MODE_PRIVATE);
    }

    public WiseCookieStore(App app) {
        this(null, app);
    }

    public WiseCookieStore setUpCookieFromPreference() {
        String cookieValue = preferences.getString(PREFERENCE_COOKIE_NAME, null);
        if (cookieValue != null) {
            HttpCookie httpCookie = new HttpCookie(COOKIE_SESSION_NAME, cookieValue);
            String domain = app.getPreferenceReader().getApiHost();
            httpCookie.setDomain(domain); // do not change, must
            httpCookie.setPath("/"); // do not change, must
            URI uri = URI.create(app.getPreferenceReader().getApiUri("/"));
            store.add(uri, httpCookie);
        }
        return this;
    }

    @Override
    public void add(URI uri, HttpCookie cookie) {
        if (uri != null
                && uri.getHost().equals(app.getPreferenceReader().getApiHost())
                && uri.getPath().startsWith("/wise/")) {
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString(PREFERENCE_COOKIE_NAME, cookie.getValue());
            if (!editor.commit()) {
                Log.e("WiseCookieStore", "cookie error");
            }
        }
        store.add(uri, cookie);
    }

    @Override
    public List<HttpCookie> get(URI uri) {
        return store.get(uri);
    }

    @Override
    public List<HttpCookie> getCookies() {
        return store.getCookies();
    }

    @Override
    public List<URI> getURIs() {
        return store.getURIs();
    }

    @Override
    public boolean remove(URI uri, HttpCookie cookie) {
        return store.remove(uri, cookie);
    }

    @Override
    public boolean removeAll() {
        return store.removeAll();
    }
}

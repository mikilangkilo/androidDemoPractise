package com.highwho.qrbinding.datasource.repository;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.highwho.qrbinding.datasource.DatabaseManager;
import com.highwho.qrbinding.entity.HospitalEntity;
import com.highwho.qrbinding.entity.ScannedEntity;

/**
 * Created by xyz on 3/15/16.
 */
public class HospitalRepository extends Repository<HospitalEntity, Integer>{

    public HospitalRepository(DatabaseManager databaseManager) {
        super(databaseManager);
    }

    @Override
    protected String getTableName() {
        return HospitalEntity.Schema.TABLE_NAME;
    }

    @Override
    protected HospitalEntity mapRecordToEntity(Cursor cursor) {
        int columnIndex = -1;
        HospitalEntity entity = new HospitalEntity();
        columnIndex = cursor.getColumnIndex(HospitalEntity.Schema._ID);
        if(columnIndex >= 0) {
            entity.setId(cursor.getInt(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(HospitalEntity.Schema.COLUMN_NAME);
        if(columnIndex >= 0) {
            entity.setName(cursor.getString(columnIndex));
        }

        columnIndex = cursor.getColumnIndex(HospitalEntity.Schema.COLUMN_ADDRESS);
        if(columnIndex >= 0) {
            entity.setAddress(cursor.getString(columnIndex));
        }
        return entity;
    }

    @Override
    protected String getIdFieldName() {
        return HospitalEntity.Schema._ID;
    }

    @Override
    public HospitalEntity save(HospitalEntity entity) {
        ContentValues contentValues = new ContentValues(4);
        if(entity.getId() != null) contentValues.put(ScannedEntity.Schema._ID, entity.getId());
        if(entity.getName() != null) contentValues.put(HospitalEntity.Schema.COLUMN_NAME, entity.getName());
        if(entity.getAddress() != null) contentValues.put(HospitalEntity.Schema.COLUMN_ADDRESS, entity.getAddress());
        long rowId = database.insertWithOnConflict(getTableName(), null, contentValues, SQLiteDatabase.CONFLICT_REPLACE);
        if(rowId < 0) {
            throw new RuntimeException("insert row id:" + rowId);
        }
        return entity;
    }
}

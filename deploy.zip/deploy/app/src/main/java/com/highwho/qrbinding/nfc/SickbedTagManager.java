package com.highwho.qrbinding.nfc;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import com.nxp.nfclib.classic.IMFClassicEV1;
import com.nxp.nfclib.exceptions.CloneDetectedException;
import com.nxp.nfclib.exceptions.ReaderException;
import com.nxp.nfclib.exceptions.SmartCardException;
import com.nxp.nfclib.ndef.FormatException;
import com.nxp.nfclib.ndef.INdefMessage;
import com.nxp.nfclib.ndef.NdefMessage;
import com.nxp.nfclib.ndef.NdefRecord;
import com.nxp.nfclib.ntag.INTag203x;
import com.nxp.nfclib.ntag.INTag213215216;
import com.nxp.nfclib.utils.Utilities;
import com.nxp.nfcliblite.NxpNfcLibLite;
import com.nxp.nfcliblite.Nxpnfcliblitecallback;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;


/**
 * Created by xyz on 2/27/16.
 */
public class SickbedTagManager {
    public interface SickbedTagCallBack {
        public void onFilterCallback(Uri uri, String code, SickbedTagException e, String uid);
    }

    private boolean inited = false;
    private Activity activity;

    //sdk
    private NxpNfcLibLite libInstance = null;

    //  system
    //private NfcAdapter nfcAdapter;

    public static SickbedTagManager createManager(Activity activity) {
        return new SickbedTagManager().initManager(activity);
    }

    private SickbedTagManager initManager(Activity activity) {
        this.activity = activity;
        //sdk
        libInstance = NxpNfcLibLite.getInstance();
//        libInstance.registerActivity(activity);
        //system
//        nfcAdapter = NfcAdapter.getDefaultAdapter(this.activity);

        inited = true;
        return this;
    }

    public boolean isInited() {
        return inited;
    }

    public SickbedTagManager startListener() {
        //sdk
        try {
            this.enableListener(true);
        } catch (SickbedTagException e) {
            throw new RuntimeException(e);
        }
        //system
//        PendingIntent pendingIntent = PendingIntent.getActivity(
//                this.activity, 0, new Intent(this.activity, this.activity.getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
//        IntentFilter ndef = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
//        try {
//            ndef.addDataType("*/*");
//            String[][] techListsArray = new String[][]{new String[]{NfcA.class.getName(), Ndef.class.getName()}};
//            IntentFilter[] intentFilters = new IntentFilter[]{ndef,};
//            nfcAdapter.enableForegroundDispatch(this.activity, pendingIntent, intentFilters, techListsArray);
//        } catch (IntentFilter.MalformedMimeTypeException e) {
//            e.printStackTrace();
//        }
        return this;
    }

    public SickbedTagManager stopListener() {
        //sdk
        try {
            this.enableListener(false);
        } catch (SickbedTagException e) {
            throw new RuntimeException(e);
        }

        //system
//        nfcAdapter.disableForegroundDispatch(this.activity);
        return this;
    }

    public void filterAndWrite(Intent intent, String writeUrl, boolean override, String password, SickbedTagCallBack callBack) {
        if (writeUrl == null) {
            callBack.onFilterCallback(null, null, new SickbedTagException("写入内容为空"), "");
        }
        readOrWriteUri(intent, writeUrl, override, password, callBack);
    }

    public void filter(Intent intent, SickbedTagCallBack callBack) {
        readOrWriteUri(intent, null, false, null, callBack);
    }

    private void readOrWriteUri(Intent intent, final String writeUrl, final boolean override, final String password, final SickbedTagCallBack callBack) {

        //system
//        Uri uri = null;
        /*if (NfcAdapter.ACTION_TECH_DISCOVERED.equals(intent.getAction())) {
            Tag tagFromIntent = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            Ndef ndef = Ndef.get(tagFromIntent);
            try {
                ndef.connect();
                NdefMessage message = ndef.getNdefMessage();
                if (message != null && message.getRecords().length > 0) {
                    uri = message.getRecords()[0].toUri();
                }
                if (writeUrl != null ) {
                    if(uri != null && !override) {
                        throw new SickbedTagException("已存在:" + uri);
                    } else {
                        NdefRecord ndefRecord = NdefRecord.createUri(writeUrl);
                        NdefMessage outMessage = new NdefMessage(ndefRecord);
                        ndef.writeNdefMessage(outMessage);
                        uri = ndefRecord.toUri();
                    }
                }
            } catch (IOException | FormatException e) {
                throw new SickbedTagException(e);
            } finally {
                if (ndef != null) {
                    try {
                        ndef.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return uri;*/
        //sdk

        Nxpnfcliblitecallback nxpnfcliblitecallback = new Nxpnfcliblitecallback() {
            @Override
            public void onClassicEV1CardDetected(IMFClassicEV1 imfClassicEV1) {

            }

            @Override
            public void onNTag213215216CardDetected(INTag213215216 inTag) {
                SickbedTagException exception = null;
                Uri uri = null;
                String nfcId = "";
                try {
//                    Log.i("read id", idToString(inTag.getUID()));

                    inTag.getReader().connect();

                    /*if((auth0 & 0xFF) == 0) {
                        byte[] retPak = pak.clone();
                        inTag.authenticatePwd(pwd, retPak);
                    }
                    inTag.programPWDPack(pwd,pak);
                    inTag.setNegativePwdLimit(127);
                    inTag.enablePasswordProtection(false, inTag.getFirstUserpage());
                    */
                    byte[] userPage = inTag.read(inTag.getFirstUserpage());
                    if (userPage[0] == 0x03 && userPage[1] == 0x18) {
                        NdefMessage message = new NdefMessage(inTag.readNDEF().toByteArray());
                        if (message.getRecords().length > 0) {
                            uri = Uri.parse(message.getRecords()[0].toUri().toString());
                        }
                    }

                    if (writeUrl != null) {
                        if (uri != null && !override) {
                            exception = new SickbedTagException("已存在:" + uri);
                        } else {
                            authenticOrWritePassword(inTag);
                            NdefRecord ndefRecord = NdefRecord.createUri(writeUrl);
                            NdefMessage outMessage = new NdefMessage(ndefRecord);
                            /*byte[] messageBytes = outMessage.toByteArray();
                            int len = messageBytes.length +1;
                            int pageN = len/4 + (len%4 == 0 ? 0 : 1);
                            byte[] resultBytes = new byte[pageN*4];
                            System.arraycopy(messageBytes, 0, resultBytes, 0, messageBytes.length);
                            resultBytes[messageBytes.length] = (byte) 0xFE;
                            for (int i=messageBytes.length; i < pageN*4; i++) {
                                resultBytes[i] = 0x00;
                            }
                            int userpage = inTag.getFirstUserpage();
                            for (int i = 0; i < pageN; i++) {
                                inTag.write(userpage+i, Arrays.copyOfRange(resultBytes, i*4, i*4+4));
                            }
//                             4 - (outMessage.toByteArray().length % 4)
//                            System.arraycopy(outMessage.toByteArray(), 0, newByte, 0, org.length);*/
                            inTag.writeNDEF(outMessage);
                            uri = Uri.parse(ndefRecord.toUri().toString());
                            Log.i("ndef write", String.format("uri is %s", uri.toString()));
                        }
                    }
                    byte[] idbytes = inTag.getUID();

                    nfcId = Utilities.byteToHexString(inTag.getUID());
                    Log.i("get id int", String.valueOf(nfcId));
                } catch (ReaderException | FormatException | SmartCardException | IOException e) {
                    exception = new SickbedTagException(e);
                    e.printStackTrace();
                } catch (SickbedTagException e) {
                    exception = new SickbedTagException(e);
                } finally {
                    if (inTag.getReader().isConnected()) {
                        try {
                            inTag.getReader().close();
                        } catch (ReaderException e) {
                            exception = new SickbedTagException(e);
                        }
                    }
                    String code = null;
                    if (uri != null && uri.getHost().contains("w-se.cn")) {
                        code = uri.getLastPathSegment();
                    }
                    if(callBack != null) {
                        callBack.onFilterCallback(uri, code, exception, nfcId);
                    }

                }

            }

            @Override
            public void onNTag203xCardDetected(INTag203x inTag) {
                SickbedTagException exception = null;
                Uri uri = null;
                String nfcId = "";
                try {
                    nfcId = Utilities.byteToHexString(inTag.getUID());
                    inTag.getReader().connect();

                    byte[] userPage = inTag.read(inTag.getFirstUserpage());
                    Log.i("userPage::::", String.format("userPage0 hex is %02x", userPage[0]));
                    Log.i("userPage::::", String.format("userPage1 hex is %02x", userPage[1]));

                    NdefMessage message = new NdefMessage(inTag.readNDEF().toByteArray());
                    if (message.getRecords().length > 0) {
                        uri = Uri.parse(message.getRecords()[0].toUri().toString());
                    }
                    if (writeUrl != null) {
                        if (uri != null && !override) {
                            exception = new SickbedTagException("已存在:" + uri);
                        } else {
                            NdefRecord ndefRecord = NdefRecord.createUri(writeUrl);
                            NdefMessage outMessage = new NdefMessage(ndefRecord);
                            inTag.writeNDEF(outMessage);
                            uri = Uri.parse(ndefRecord.toUri().toString());
                            Log.i("ndef write", String.format("uri is %s", uri.toString()));
                        }
                    }
                } catch (ReaderException | FormatException | SmartCardException | IOException e) {
                    exception = new SickbedTagException(e);
                    e.printStackTrace();
                } finally {
                    if (inTag.getReader().isConnected()) {
                        try {
                            inTag.getReader().close();
                        } catch (ReaderException e) {
                            exception = new SickbedTagException(e);
                        }
                    }
                    String code = null;
                    if (uri != null && uri.getHost().contains("w-se.cn")) {
                        code = uri.getLastPathSegment();
                    }
                    callBack.onFilterCallback(uri, code, exception, nfcId);
                }
            }
        };

        try {
            libInstance.filterIntent(intent, nxpnfcliblitecallback);
        } catch (CloneDetectedException e) {
            callBack.onFilterCallback(null, null, new SickbedTagException(e), "");
        }
    }

    private void authenticOrWritePassword(INTag213215216 inTag) throws SickbedTagException{
        try {
            byte auth0 = (inTag.read(0x29))[3];
            byte[] hash = createPassword(inTag.getUID());
            byte[] pwd = Arrays.copyOfRange(hash, 0, 4);
            byte[] pack = Arrays.copyOfRange(hash, 4, 6);
//            Log.d("create password", String.format("password:%s, pack:%s",
//                    Utilities.byteToHexString(pwd), Utilities.byteToHexString(pack)));


            if (pack[0] == 0 && pack[1] == 0 ) {
                pack[0] = hash[6];
                pack[1] = (byte)(hash[7] & 0x01);
            }

            if ((((int) auth0) & 0x00000000FF) == 0x000000ff) {
                System.out.println("tag is not authed");

                Log.i("nfc auth", "set password begin");
                inTag.programPWDPack(pwd, pack);
                Log.i("nfc auth", "programPWDPack finish");
                inTag.setNegativePwdLimit((byte) 7);
                Log.i("nfc auth", "setNegativePwdLimit finish");
                inTag.enablePasswordProtection(false, inTag.getFirstUserpage());
                Log.i("nfc auth", "enablePasswordProtection finish");
                Log.i("nfc auth", "set password finish");
            }
            inTag.authenticatePwd(pwd, pack);
            Log.i("nfc authentic", "authentic password success");
        } catch (SmartCardException | IOException | NoSuchAlgorithmException e) {
            throw new SickbedTagException("验证失败", e);
        }

    }


    private final byte[] key = {0x18, 0x5f, 0x01, (byte) 0xef};

    private byte[] createPassword(byte[] bytes) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-1");
        digest.update(bytes, 0, bytes.length);
        digest.update(key, 0, key.length);
        byte[] pwd = digest.digest();
        return Arrays.copyOf(pwd, 8);
    }


    public void enableListener(boolean enable) throws SickbedTagException{
        if(!this.inited) {
            throw new SickbedTagException("tag manager not inited");
        }
        this.libInstance.registerActivity(activity);
        if(enable) {
            this.libInstance.startForeGroundDispatch();
        } else {
            this.libInstance.stopForeGroundDispatch();
        }
    }

    private String idToString(byte[] id) {
        String str = new String();
        for (int i = 0; i < id.length; i++) {
            str += String.format(":%02X", id[i]);
        }
        return str.isEmpty() ? "" : str.substring(1);


    }
}

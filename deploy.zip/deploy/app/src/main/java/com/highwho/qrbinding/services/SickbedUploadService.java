package com.highwho.qrbinding.services;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.NotificationCompat;
import android.util.JsonWriter;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.highwho.qrbinding.App;
import com.highwho.qrbinding.R;
import com.highwho.qrbinding.common.http.WiseJsonObjectRequest;
import com.highwho.qrbinding.datasource.DatabaseManager;
import com.highwho.qrbinding.datasource.repository.SEntityRepository;
import com.highwho.qrbinding.entity.EntityHelper;
import com.highwho.qrbinding.entity.ScannedEntity;

import org.json.JSONObject;

import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by xyz on 3/17/16.
 */
public class SickbedUploadService extends IntentService {

    private static final int FRONT_UPLOAD_SERVICE = 1;
    private NotificationManager mNotificationManager;
    private SEntityRepository sEntityRepository;
    private RequestQueue mRequestQueue;
    private Handler handler = new Handler();
    private NotificationCompat.Builder builder;
    private int maxSize = 0;

    public SickbedUploadService() {
        super(SickbedUploadService.class.getSimpleName());

    }

    @Override
    public void onCreate() {
        super.onCreate();
        mNotificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        sEntityRepository = new SEntityRepository(DatabaseManager.getWiseInstance(this));
        mRequestQueue = App.wiseRequestQueue(this);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        AtomicInteger atomicInteger = new AtomicInteger(0);
        builder = new NotificationCompat.Builder(this);
        List<ScannedEntity> list = sEntityRepository.findUnSynced();
        maxSize = list.size();
        startNotification(buildNotification(0, maxSize, builder));

        for (int i = 0; i < maxSize; i++) {
            uploadData(list.get(i), atomicInteger);
        }
        try {
            while (!atomicInteger.compareAndSet(maxSize, 0)) {
                Thread.sleep(1000);
            }
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(SickbedUploadService.this, "数据上传完成", Toast.LENGTH_LONG).show();
                }
            });
        } catch (InterruptedException e) {
            Log.e(this.getClass().getSimpleName(), "onHandleIntent", e);
        }
        stopNotification();
    }

    private Notification buildNotification(int index, int max, NotificationCompat.Builder builder) {
        builder.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("病床信息上传")
                .setContentText("病床信息上传中:" + index)
                .setProgress(max, index, false);
//                .setContentIntent(pendingIntent);
        return builder.build();
    }

    /*private String toJsonObject(ScannedEntity sickbedEntity) {
        StringWriter stringWriter = new StringWriter();
        JsonWriter writer = null;
        try {
            writer = new JsonWriter(stringWriter);
            writer.beginObject();
            writer.name("code").value(sickbedEntity.getCode());
            writer.name("hid").value(sickbedEntity.getHospitalId());
            writer.name("number").value(sickbedEntity.getName());
            if (sickbedEntity.getNfcId() != null)
                writer.name("nfcid").value(sickbedEntity.getNfcId());
            writer.name("modified").value(sickbedEntity.getModifyDate().getTime());
            writer.name("division").value(sickbedEntity.getDivision());
            if (sickbedEntity.getRegion() != null)
                writer.name("region").value(sickbedEntity.getRegion());
            if (sickbedEntity.getFloor() != null)
                writer.name("floor").value(sickbedEntity.getFloor());
            if (sickbedEntity.getBuilding() != null)
                writer.name("building").value(sickbedEntity.getBuilding());
            writer.endObject();
            writer.flush();
            String json = stringWriter.toString();
            return json;
        } catch (IOException | NullPointerException e) {
            Log.e(this.getClass().getSimpleName(), "toJsonObject", e);
            return null;
        } finally {
            if (writer != null) try {
                writer.close();
            } catch (IOException e) {
                Log.e(this.getClass().getSimpleName(), "toJsonObject.close", e);
            }
        }
    }*/

    private void uploadData(final ScannedEntity scannedEntity, final AtomicInteger atomicInteger) {
        StringWriter stringWriter = null;
        try {
            stringWriter = new StringWriter();
            JsonWriter writer = new JsonWriter(stringWriter);
            EntityHelper.writeSEntityToJson(scannedEntity, writer);
            writer.close();
            Request<JSONObject> request =
                    new WiseJsonObjectRequest(
                            Request.Method.POST,
                            App.preferenceReader(this).getApiUri(String.format("/hospital/%s/etag_deployment", scannedEntity.getHospitalId())),
                            stringWriter.toString(),
                            new Response.Listener<JSONObject>() {
                                @Override
                                public void onResponse(JSONObject response) {
                                    onUploadSuccess(scannedEntity, response, atomicInteger);
                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    onUploadError(scannedEntity, error, atomicInteger);
                                }
                            },
                            App.authenticManager(this).getToken()
                    );
            request = mRequestQueue.add(request);
        } catch (IOException e) {
            Log.e(this.getClass().getSimpleName(), "uploadData", e);
        }
    }

    private void updateNotification(AtomicInteger integer) {
        mNotificationManager.notify(
                FRONT_UPLOAD_SERVICE,
                buildNotification(integer.incrementAndGet(), maxSize, builder)
        );
    }

    private void onUploadSuccess(@NonNull ScannedEntity scannedEntity, JSONObject jsonObject, AtomicInteger atomicInteger) {
        long modifyTime = 0;
        if (scannedEntity.getModifyDate() != null) {
            modifyTime = scannedEntity.getModifyDate().getTime();
        }
        if (!sEntityRepository.updateModify(modifyTime, scannedEntity.getCode())) {
            Log.e(this.getClass().getSimpleName(), "update sickbed sync error");
        }
        updateNotification(atomicInteger);
    }

    private void onUploadError(@NonNull ScannedEntity scannedEntity, VolleyError error, AtomicInteger atomicInteger) {
        String cause = "onUploadError:";
        String desc = "";
        if (error.networkResponse != null) {
            try {
                desc = new String(error.networkResponse.data, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        } else {
            desc = error.getMessage();
        }
        Log.e(this.getClass().getSimpleName(), "onUploadError:" + desc, error);
        updateNotification(atomicInteger);
        final String toastTest = desc;
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(SickbedUploadService.this, "上传异常:" + toastTest, Toast.LENGTH_SHORT).show();
            }
        });
    }


    private Notification startNotification(Notification notification) {
//        Intent serviceIntent = new Intent(this, SickbedUploadService.class);
//        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, , 0);
        startForeground(FRONT_UPLOAD_SERVICE, notification);
        return notification;
    }

    private void stopNotification() {
        stopForeground(true);
    }


}

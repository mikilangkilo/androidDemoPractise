package com.highwho.qrbinding.common.loader.volley;

/**
 * Created by xyz on 3/12/16.
 */
public class VolleyLoaderException extends Exception {

    public VolleyLoaderException() {
    }

    public VolleyLoaderException(String detailMessage) {
        super(detailMessage);
    }

    public VolleyLoaderException(String detailMessage, Throwable throwable) {
        super(detailMessage, throwable);
    }

    public VolleyLoaderException(Throwable throwable) {
        super(throwable);
    }
}

package com.highwho.qrbinding.common.loader.volley;

import android.content.Context;
import android.os.AsyncTask;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.highwho.qrbinding.datasource.repository.Repository;

import org.json.JSONArray;

import java.util.List;

/**
 * Created by xyz on 3/15/16.
 */
public abstract class SqlVolleyArrayLoader<T, K> extends JsonArrayLoader<T> {

    private boolean mSync = false;
    private Repository<T, K> repository;

    private LoadSqlDataTask loadSqlDataTask;
    private DumpSqlDataTask dumpSqlDataTask;

    public SqlVolleyArrayLoader(Context context, RequestQueue requestQueue, boolean mSync, Repository<T, K> repository) {
        super(context, requestQueue);
        this.mSync = mSync;
        this.repository = repository;
    }

    public SqlVolleyArrayLoader(Context context, boolean mSync, Repository<T, K> repository) {
        super(context);
        this.mSync = mSync;
        this.repository = repository;
    }

    public SqlVolleyArrayLoader(Context context, Repository<T, K> repository) {
        super(context);
        this.repository = repository;
    }

    @Override
    protected void onForceLoad() {
        if (!mSync) {
            forceLoadFromDb();
        } else {
            super.onForceLoad();
        }
    }

    private void forceLoadFromDb() {
        loadSqlDataTask = new LoadSqlDataTask();
        loadSqlDataTask.execute();
    }

    @Override
    public void onResponse(JSONArray response) {
        super.onResponse(response);
        dumpSqlDataTask = new DumpSqlDataTask(getContent().getData());
        dumpSqlDataTask.execute();
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        onVolleyLoadedWithError(error);
        forceLoadFromDb();
    }

    protected void onVolleyLoadedWithError(VolleyError error) {

    }

    protected void onSynFinished(Exception e) {

    }

    protected abstract void dumpDataToDB(List<T> dataList, Repository<T, K> repository);

    protected abstract List<T> queryDataFromDB(Repository<T, K> repository);

    @Override
    protected boolean onCancelLoad() {
        if (dumpSqlDataTask != null && !dumpSqlDataTask.isCancelled()) {
            dumpSqlDataTask.cancel(false);
        }
        if (loadSqlDataTask != null && !loadSqlDataTask.isCancelled()) {
            loadSqlDataTask.cancel(true);
        }
        return super.onCancelLoad();
    }

    protected class LoadSqlDataTask extends AsyncTask<String, Void, List<T>> {
        @Override
        protected List<T> doInBackground(String... params) {
            return SqlVolleyArrayLoader.this.queryDataFromDB(repository);
        }

        @Override
        protected void onPostExecute(List<T> ts) {
            super.onPostExecute(ts);
            SqlVolleyArrayLoader.this.setContent(ts, null);
            SqlVolleyArrayLoader.this.deliverResult(getContent());
        }
    }

    protected class DumpSqlDataTask extends AsyncTask<Void, Void, Exception> {

        List<T> dataList;

        public DumpSqlDataTask(List<T> dataList) {
            this.dataList = dataList;
        }

        @Override
        protected Exception doInBackground(Void... params) {
            Exception exception = null;
            try {
                SqlVolleyArrayLoader.this.dumpDataToDB(dataList, repository);
            } catch (Exception e) {
                exception = e;
            }
            return exception;
        }

        @Override
        protected void onPostExecute(Exception e) {
            SqlVolleyArrayLoader.this.onSynFinished(e);
            SqlVolleyArrayLoader.this.mSync = false;
        }
    }

}

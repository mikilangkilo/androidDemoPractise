package com.highwho.qrbinding;

import com.journeyapps.barcodescanner.CaptureActivity;
import com.journeyapps.barcodescanner.CompoundBarcodeView;

/**
 * Created by xyz on 2/21/16.
 */
public class QrCaptureActivity extends CaptureActivity {
    @Override
    protected CompoundBarcodeView initializeContent() {
        setContentView(R.layout.captureqr);
        return (CompoundBarcodeView)findViewById(R.id.qr_scanner);
    }
}

package com.highwho.qrbinding.etag.barcode;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.highwho.qrbinding.QrCaptureActivity;
import com.highwho.qrbinding.R;
import com.highwho.qrbinding.etag.ETagDetector;
import com.highwho.qrbinding.etag.TagDataExtractor;

/**
 * Created by xyz on 3/3/16.
 */
public class BarCodeDetector extends ETagDetector<BarCodeTag>{

    public BarCodeDetector(Activity activity) {
        super(activity);
    }

    public void start() {
        IntentIntegrator integrator;
        integrator = new IntentIntegrator(this.activity);

        integrator.setOrientationLocked(false);
        integrator.setCaptureActivity(QrCaptureActivity.class);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
        if(this.activity != null) {
            String prompt = this.activity.getResources().getString(R.string.barcode_detect_prompt);
            integrator.setPrompt(prompt);
        }
        integrator.initiateScan();
    }

    @Override
    public BarCodeTag onFilterIntent(Intent intent, int requestCode, int resultCode) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
        BarCodeTag barCodeTag = null;
        if(result != null && result.getContents() != null) {
            barCodeTag = new BarCodeTag(result);
        }
        return barCodeTag;
    }
}

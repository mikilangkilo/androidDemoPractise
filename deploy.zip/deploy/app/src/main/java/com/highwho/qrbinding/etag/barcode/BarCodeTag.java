package com.highwho.qrbinding.etag.barcode;

import android.net.Uri;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.highwho.qrbinding.etag.ETag;

/**
 * Created by xyz on 3/3/16.
 */
public class BarCodeTag extends ETag {
    private IntentResult result;

    public BarCodeTag(IntentResult result) {
        this.result = result;
    }

    public IntentResult getResult() {
        return result;
    }

    public String getStringContent() {
        if(result != null) {
            return result.getContents();
        }
        return null;
    }
}

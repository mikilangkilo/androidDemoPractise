package com.highwho.qrbinding;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.preference.PreferenceManager;
import android.test.PerformanceTestCase;
import android.util.Log;
import android.util.LruCache;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.Volley;
import com.highwho.qrbinding.common.authentic.AuthenticManager;
import com.highwho.qrbinding.common.http.WiseCookieStore;

import org.json.JSONObject;

import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.CookieStore;

/**
 * Created by xyz on 3/11/16.
 */
public class App {
    private static volatile App mInstance;
    private final Context mCtx;

    private RequestQueue mRequestQueue;
    private AuthenticManager mAuthenticManager;
    private PreferenceReader mPreferenceReader;

    private static  App getInstance(Context context) {
        if (mInstance == null) {
            synchronized (App.class) {
                if(mInstance == null) mInstance = new App(context).init();
            }
        }
        return mInstance;
    }

    public static PreferenceReader preferenceReader(Context context) {
       return  getInstance(context).getPreferenceReader();
    }

    public static AuthenticManager authenticManager(Context context) {
        return  getInstance(context).getAuthenticManager();
    }

    public static RequestQueue wiseRequestQueue(Context context) {
        return  getInstance(context).getWiseRequestQueue();
    }

    private App(Context context) {
        mCtx = context;
    }

    private App init() {
        mPreferenceReader = new PreferenceReader(); // must first init
        mPreferenceReader.initPreference();
        initWiseRequestQueue(this);
        initAuthenticManager(this);
        return this;
    }

    private synchronized void initWiseRequestQueue(App app) {
//        CookieStore cookieStore = new WiseCookieStore(app).setUpCookieFromPreference();
//        CookieManager cookieManager = new CookieManager(cookieStore, CookiePolicy.ACCEPT_ORIGINAL_SERVER);
//        CookieHandler.setDefault(cookieManager);
        mRequestQueue = Volley.newRequestQueue(app.getContext().getApplicationContext());
    }

    private synchronized void initAuthenticManager(App app) {
        mAuthenticManager = new AuthenticManager(mRequestQueue, app);

    }

    private RequestQueue getWiseRequestQueue() {
        return mRequestQueue;
    }

    public Context getContext() {
        return mCtx;
    }

    public AuthenticManager getAuthenticManager() {
        return mAuthenticManager;
    }

    public PreferenceReader getPreferenceReader() {
        return mPreferenceReader;
    }

    public class PreferenceReader {
        private String apiHostkey;
        private String apiProtoclkey;
//        private final String apiHost = mCtx.getResources().getString(R.string.api_url_host);
//        private final String apiScheme = mCtx.getResources().getString(R.string.api_url_scheme);

        private SharedPreferences defaultPreference;

        public void initPreference() {
            apiHostkey = mCtx.getResources().getString(R.string.preference_key_api_host);
            apiProtoclkey = mCtx.getResources().getString(R.string.preference_key_api_protocol);
            defaultPreference = PreferenceManager.getDefaultSharedPreferences(mCtx);
        }

        public String getScheme() {
            return defaultPreference.getString(apiProtoclkey, "");
        }

        public String getApiHost() {
            return defaultPreference.getString(apiHostkey, "");
        }

        public String getApiUri(String path) {
            return String.format("%s://%s/wise/rest/v1%s", getScheme(), getApiHost(), path);
        }
    }
}
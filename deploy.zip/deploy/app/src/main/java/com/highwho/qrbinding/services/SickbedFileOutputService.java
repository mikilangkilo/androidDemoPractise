package com.highwho.qrbinding.services;

import android.app.IntentService;
import android.content.Intent;
import android.os.Environment;
import android.os.Handler;
import android.util.JsonWriter;
import android.util.Log;
import android.widget.Toast;

import com.highwho.qrbinding.R;
import com.highwho.qrbinding.datasource.DatabaseManager;
import com.highwho.qrbinding.datasource.repository.SEntityRepository;
import com.highwho.qrbinding.entity.EntityHelper;
import com.highwho.qrbinding.entity.ScannedEntity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Created by xyz on 3/15/16.
 */
public class SickbedFileOutputService extends IntentService {
    private SEntityRepository sEntityRepository;
    private Handler mHandler;

    public SickbedFileOutputService() {
        super(SickbedFileOutputService.class.getSimpleName());
        mHandler = new Handler();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sEntityRepository = new SEntityRepository(
                DatabaseManager.getWiseInstance(this.getApplicationContext()));

    }

    @Override
    protected void onHandleIntent(Intent intent) {
        exportData(intent);
    }


    private void exportData(Intent intent) {
        Log.d(this.getClass().getSimpleName(), "exportData start");
        FileOutputStream outputStream = null;
        try {
            if (!isExternalStorageWritable()) {
                throw new IOException("当前磁盘不可写");
            }
            String filename = getResources().getString(R.string.wise_sickbed_file_name);
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss_", Locale.CHINESE);
            filename = dateFormat.format(new Date()) + filename;
            File file = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), filename);
            outputStream = new FileOutputStream(file, false);
            writeSickbedJson(this.sEntityRepository.findUnSynced(), outputStream);
            outputStream.close();
            postToastMessage("导出数据成功:", Toast.LENGTH_SHORT);
        } catch (IOException | RuntimeException e) {
            Log.e(this.getClass().getSimpleName(), "exportData", e);
            postToastMessage("导出数据失败:" + e.getMessage(), Toast.LENGTH_LONG);
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException es) {
                    es.printStackTrace();
                }
            }
        }
    }

    private void writeSickbedJson(List<ScannedEntity> entities, FileOutputStream fileStream) {
        JsonWriter writer = null;
        try {
            for (ScannedEntity entity :entities) {
                writer = new JsonWriter(new OutputStreamWriter(fileStream, "UTF-8"));
                EntityHelper.writeSEntityToJson(entity, writer);
                fileStream.write("\n".getBytes());
            }
        } catch (IOException | RuntimeException e) {
            Log.e(this.getClass().getSimpleName(), "writeSickbedJson", e);
        } finally {
            if (writer != null) try {
                writer.close();
            } catch (IOException e) {
                Log.e(EntityHelper.class.getSimpleName(), "toJsonObject.close", e);
            }
        }
    }

    private boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state);
    }

    private void postToastMessage(final CharSequence message, final int duration) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(SickbedFileOutputService.this, message, duration).show();
            }
        });
    }
}

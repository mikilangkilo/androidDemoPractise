package com.highwho.qrbinding.etag.nfc;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.util.Log;

import com.highwho.qrbinding.etag.ETagDetector;
import com.highwho.qrbinding.etag.ETagException;

/**
 * Created by xyz on 3/3/16.
 */
public class NfcTagDetector extends ETagDetector<NfcTag> {
    private NfcAdapter nfcAdapter;

    public NfcTagDetector(NfcAdapter nfcAdapter, Activity activity) {
        super(activity);
        this.nfcAdapter = nfcAdapter;
    }

    public void start() throws ETagException{
        if(nfcAdapter != null) {
            PendingIntent pendingIntent = PendingIntent.getActivity(
                    this.activity, 0, new Intent(this.activity, this.activity.getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
            IntentFilter ndef = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
            String[][] techListsArray = new String[][]{new String[]{Ndef.class.getName()}};
            nfcAdapter.enableForegroundDispatch(activity,pendingIntent,new IntentFilter[]{ndef}, techListsArray);
        } else {
            Log.w("NfcTagDetector", "NfcAdapter is adapter, not support");
//            throw new ETagException("nfc adapter is null");
        }
    }

    public void stop() throws ETagException{
        if(nfcAdapter != null) {
            nfcAdapter.disableForegroundDispatch(this.activity);
        } else {
            Log.w("NfcTagDetector", "NfcAdapter is adapter, not support");
//            throw new ETagException("nfc adapter is not exist");
        }
    }

    @Override
    public NfcTag onFilterIntent(Intent intent, int requestCode, int resultCode) {
        NfcTag nfcTag = null;
        if(intent != null && NfcAdapter.ACTION_TECH_DISCOVERED.equals(intent.getAction())) {
            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            nfcTag = new NfcTag(tag);
        }
        return nfcTag;
    }
}

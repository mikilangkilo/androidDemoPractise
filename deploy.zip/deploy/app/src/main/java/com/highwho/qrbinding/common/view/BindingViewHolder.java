package com.highwho.qrbinding.common.view;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by xyz on 3/7/16.
 */
public abstract class BindingViewHolder<V extends View> extends RecyclerView.ViewHolder {
    private ViewDataBinding viewDataBinding;
    private V view;
    public BindingViewHolder(View itemView) {
        super(itemView);
        viewDataBinding = DataBindingUtil.bind(itemView);
    }

    public BindingViewHolder(View itemView, ViewDataBinding viewDataBinding) {
        super(itemView);
        this.viewDataBinding = viewDataBinding;
    }

    protected ViewDataBinding getDataBinding() {
        return viewDataBinding;
    }

    public V binderData(Object data, int variableId) {
        viewDataBinding.setVariable(variableId, data);
        viewDataBinding.executePendingBindings();
        return ((V) viewDataBinding.getRoot());
    }

}

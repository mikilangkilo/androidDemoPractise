package com.highwho.qrbinding.fragment;

import android.app.AlertDialog;
import android.app.ListFragment;
import android.content.DialogInterface;
import android.content.Loader;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.highwho.qrbinding.BR;
import com.highwho.qrbinding.R;
import com.highwho.qrbinding.common.AppUtil;
import com.highwho.qrbinding.common.loader.volley.LoaderContent;
import com.highwho.qrbinding.common.loader.volley.VolleyLoader;
import com.highwho.qrbinding.common.view.adapter.DataBindingArrayAdapter;
import com.highwho.qrbinding.datasource.DatabaseManager;
import com.highwho.qrbinding.datasource.repository.DivisionRepository;
import com.highwho.qrbinding.datasource.repository.HospitalRepository;
import com.highwho.qrbinding.datasource.repository.Repository;
import com.highwho.qrbinding.entity.DivisionEntity;
import com.highwho.qrbinding.entity.HospitalEntity;
import com.highwho.qrbinding.loader.DivisionLoader;
import com.highwho.qrbinding.loader.HospitalsLoader;

import java.util.List;

/**
 * Created by xyz on 3/9/16.
 */
public class HospitalsFragment extends ListFragment implements AdapterView.OnItemLongClickListener {
    public interface OnHospitalSelectListener {
        boolean onSelectedHospital(HospitalEntity entity, View view, int position);
    }

    private static final String HOSPITAL_SELECT_HID_BUNDLE_NAME = "HOSPITAL_SELECT_INDEX_STATE";
    private static final String HOSPITAL_SYN_BUNDLE_NAME = "HOSPITAL_SYN_BUNDLE_NAME";
    private static final String DIVISION_SYN_BUNDLE_NAME = "DIVISION_SYN_BUNDLE_NAME";

    private static final int LOADER_HOSPITALS_KEY = 10000;
    private static final int LOADER_DIVISIONS_KEY = 20000;
    private DataBindingArrayAdapter<HospitalEntity, Integer> arrayAdapter;
    private OnHospitalSelectListener onHospitalSelectListener;
    private HospitalsLoader hospitalsLoader;
    private DivisionLoader divisionLoader;
    private SwipeRefreshLayout refreshLayout;

    private VolleyLoader.VolleyLoaderCallbacks<List<HospitalEntity>> hospitalsLoaderCallback;
    private VolleyLoader.VolleyLoaderCallbacks<List<DivisionEntity>> divisionLoaderCallback;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Log.d("HospitalsFragment", "onCreateView");

        arrayAdapter =
                new HospitalsSelectAdapter(this.getActivity(), R.layout.hospital_info_row, BR.hospital);

        if (savedInstanceState != null) {
            arrayAdapter.setRemarkKey(savedInstanceState.getInt(HOSPITAL_SELECT_HID_BUNDLE_NAME, -1));
        }

        setListAdapter(arrayAdapter);
        if (this.getActivity() instanceof OnHospitalSelectListener) {
            onHospitalSelectListener = (OnHospitalSelectListener) this.getActivity();
        }
        return inflater.inflate(R.layout.hospital_list, container, false);
    }


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ListView listView = getListView();
        if (listView != null) {
            listView.setOnItemLongClickListener(this);
        }
        if (getView() != null) {
            initRefreshView(getView());
        }

        hospitalsLoaderCallback = new VolleyLoader.VolleyLoaderCallbacks<List<HospitalEntity>>() {
            @Override
            public Loader<LoaderContent<List<HospitalEntity>>> onCreateLoader(int id, Bundle args) {
                if (id == LOADER_HOSPITALS_KEY)  {
                    hospitalsLoader = getHospitalLoader(args);
                }
                return hospitalsLoader;
            }

            @Override
            public void onLoadFinished(Loader<LoaderContent<List<HospitalEntity>>> loader, LoaderContent<List<HospitalEntity>> data) {
                if (loader.getId() == LOADER_HOSPITALS_KEY) {
                    if (data.getException() != null) {
                        AppUtil.showError(HospitalsFragment.this.getActivity(), "加载医院数据有误", data.getException());
                        data.getException().printStackTrace();
                    }
                    arrayAdapter.clear();
                    if (data.getData() != null) {
                        arrayAdapter.addAll(data.getData());
                    }
                    arrayAdapter.notifyDataSetChanged();
//                    if (refreshLayout != null) refreshLayout.setRefreshing(false);
                }
            }

            @Override
            public void onLoaderReset(Loader<LoaderContent<List<HospitalEntity>>> loader) {
                arrayAdapter.clear();
                arrayAdapter.notifyDataSetInvalidated();
            }
        };

        divisionLoaderCallback = new VolleyLoader.VolleyLoaderCallbacks<List<DivisionEntity>>() {
            @Override
            public Loader<LoaderContent<List<DivisionEntity>>> onCreateLoader(int id, Bundle args) {
                if (id == LOADER_DIVISIONS_KEY)  {
                    divisionLoader = getDivisionLoader(args);
                }
                return divisionLoader;
            }

            @Override
            public void onLoadFinished(Loader<LoaderContent<List<DivisionEntity>>> loader, LoaderContent<List<DivisionEntity>> data) {
                if (data.getException() != null) {
                    AppUtil.showError(HospitalsFragment.this.getActivity(), "加载科室数据有误", data.getException());
                    data.getException().printStackTrace();
                }
                if (refreshLayout != null) refreshLayout.setRefreshing(false);
            }

            @Override
            public void onLoaderReset(Loader<LoaderContent<List<DivisionEntity>>> loader) {

            }
        };

        getLoaderManager().initLoader(LOADER_HOSPITALS_KEY, savedInstanceState, hospitalsLoaderCallback);
        getLoaderManager().initLoader(LOADER_DIVISIONS_KEY, savedInstanceState, divisionLoaderCallback);

    }


    private void initRefreshView(@NonNull View view) {
        refreshLayout =
                ((SwipeRefreshLayout) view.findViewById(R.id.swipe_refresh_layout));

//        if (refreshLayout == null) return;

        refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                syncHospitalData();
            }
        });
    }

    private void syncHospitalData() {
        Bundle bundle = new Bundle();
        bundle.putBoolean(HOSPITAL_SYN_BUNDLE_NAME, true);
        getLoaderManager().restartLoader(LOADER_HOSPITALS_KEY, bundle, this.hospitalsLoaderCallback);
        getLoaderManager().restartLoader(LOADER_DIVISIONS_KEY, bundle, this.divisionLoaderCallback);
    }

    private HospitalsLoader getHospitalLoader(Bundle args) {
        boolean sync = false;
        if (args != null) {
            sync = args.getBoolean(HOSPITAL_SYN_BUNDLE_NAME, false);
        }
        Repository<HospitalEntity, Integer> repository = new HospitalRepository(
                DatabaseManager.getWiseInstance(getActivity()));

        return new HospitalsLoader(this.getActivity(), sync, repository);
    }

    private DivisionLoader getDivisionLoader(Bundle args) {
        boolean sync = false;
        if (args != null) {
            sync = args.getBoolean(HOSPITAL_SYN_BUNDLE_NAME, false);
        }
        Repository<DivisionEntity, Integer> repository = new DivisionRepository(
                DatabaseManager.getWiseInstance(getActivity()));
        return new DivisionLoader(this.getActivity(), sync, repository);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d("HospitalsFragment", "onSaveInstanceState");
        Integer hid = arrayAdapter.getRemarkKey();
        if (hid != null) {
            outState.putInt(HOSPITAL_SELECT_HID_BUNDLE_NAME, hid);
        }
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, final View view, final int position, long id) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage("是否选择医院")
                .setTitle("医院操作").setPositiveButton("是", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                boolean result = false;
                if (onHospitalSelectListener != null) {
                    result = onHospitalSelectListener.onSelectedHospital(arrayAdapter.getItem(position), view, position);
                }
                if (result) {
//                    arrayAdapter.setRemarkKey(arrayAdapter.getItem(position).getId());
//                    arrayAdapter.notifyDataSetChanged();
                }
            }
        }).setNegativeButton("否", null);

        builder.create().show();
        return true;
    }


}

package com.highwho.qrbinding.common.loader.volley;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Loader;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.highwho.qrbinding.App;

/**
 * Created by xyz on 3/12/16.
 */
public abstract class VolleyLoader<D, T, R extends Request<T>> extends Loader<LoaderContent<D>> implements Response.Listener<T>, Response.ErrorListener  {

    public interface VolleyLoaderCallbacks<D> extends LoaderManager.LoaderCallbacks<LoaderContent<D>> {

    }

    private RequestQueue requestQueue;
    private R request;
    private LoaderContent<D> content;

    public VolleyLoader(Context context, RequestQueue requestQueue) {
        super(context);
        this.requestQueue = requestQueue;
    }

    public VolleyLoader(Context context) {
        super(context);
        this.requestQueue = App.wiseRequestQueue(context);
    }


    protected R initRequest() {
        return initRequest(this,this);
    }

    protected abstract R initRequest(Response.Listener<T> listener, Response.ErrorListener errorListener);


    protected boolean hasContent() {
        return content != null;
    }

    protected void setContent(D data, VolleyLoaderException e) {
        this.content = new LoaderContent<>(data, e);
    }

    protected LoaderContent<D> getContent() {
        return content;
    }

    protected void onDeliverResult(LoaderContent<D> data) {
        this.content = data;
    }

    private R getRequest() {
        if (request == null) {
            request = initRequest();
        }
        return request;
    }

    @Override
    protected void onStartLoading() {
        if (takeContentChanged() || !hasContent()) {
            forceLoad();
        } else {
            deliverResult(getContent());
        }
    }

    @Override
    public void deliverResult(LoaderContent<D> data) {
        onDeliverResult(data);
        super.deliverResult(data);
    }

    @Override
    protected void onForceLoad() {
        if (requestQueue == null) {
            throw new RuntimeException("request queue is null");
        }
        requestQueue.add(getRequest());
    }

    @Override
    protected boolean onCancelLoad() {
        boolean cancelAvailable = false;
        if (!isStarted() || request == null || request.isCanceled()) {

        } else {
            request.cancel();
            cancelAvailable = true;
        }
        content = null;
        request = null;
        return cancelAvailable;
    }

    @Override
    protected void onStopLoading() {
        onCancelLoad();
        request = null;
    }

    @Override
    protected void onReset() {
        onStartLoading();
    }


    @Override
    public void onErrorResponse(VolleyError error) {
        setContent(null, new VolleyLoaderException(error));
        deliverResult(getContent());
    }
}

package com.highwho.qrbinding.etag;

/**
 * Created by xyz on 3/3/16.
 */
public abstract class ETag {

    private long detectedTime;

    public long getTime() {
        return detectedTime;
    }
}

package com.highwho.qrbinding.entity;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.provider.BaseColumns;
import android.util.Log;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by xyz on 3/3/16.
 */
public class ScannedEntity implements Parcelable {
    public static abstract class Schema implements BaseColumns {
        public static final String TABLE_NAME = "scanned_entity";

        public static final String COLUMN_ENTITY_CLASS = "entity_class";

        public static final String COLUMN_ENTITY_NAME = "entity_number";
        public static final String COLUMN_BED_EXTRA = "bed_extra";

        public static final String COLUMN_DIVISION = "division";
        public static final String COLUMN_REGION = "region";
        public static final String COLUMN_BUILDING = "building";
        public static final String COLUMN_FLOOR = "floor";

        public static final String COLUMN_WARD_NUMBER = "ward_number";
        public static final String COLUMN_WARD_CAPACITY = "ward_capacity";
        public static final String COLUMN_WARD_GENDER = "ward_gender";

        public static final String COLUMN_NFC_ID = "nfc_id";
        public static final String COLUMN_HID = "hid";
        public static final String COLUMN_CREATE_TIME = "create_time";
        public static final String COLUMN_MODIFY_TIME = "modify_time";
        public static final String COLUMN_MODIFY_SYNCED = "modify_synced";

    }

    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINESE);

    private String code;
    private String name;
    private String category;
    private String region;
    private Integer divisionId;
    private Date createDate;
    private Date modifyDate; // last modify date
    private boolean synced;
    private String nfcId;
    private Integer hospitalId;
    private HospitalEntity hospital;
    private String building;
    private String floor;
    private String wardNumber;
    private int wardCapacity = 0;
    private int wardGender = 0;
    private Boolean extraBed = false;

    public ScannedEntity() {

    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getNfcId() {
        return nfcId;
    }

    public void setNfcId(String nfcId) {
        this.nfcId = nfcId;
    }

    public Integer getDivision() {
        return divisionId;
    }

    public void setDivision(Integer divisionId) {
        this.divisionId = divisionId;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getWardNumber() {
        return wardNumber;
    }

    public void setWardNumber(String wardNumber) {
        this.wardNumber = wardNumber;
    }

    public int getWardCapacity() {
        return wardCapacity;
    }

    public void setWardCapacity(int wardCapacity) {
        this.wardCapacity = wardCapacity;
    }

    public int getWardGender() {
        return wardGender;
    }

    public void setWardGender(int wardGender) {
        this.wardGender = wardGender;
    }

    public Boolean getExtraBed() {
        return extraBed;
    }

    public void setExtraBed(Boolean extraBed) {
        this.extraBed = extraBed;
    }

    public String ward_capacity() {
        return String.valueOf(this.getWardCapacity());
    }

    public String lastDate() {
        String ret = "";
        if (this.modifyDate != null) {
            ret = DATE_FORMAT.format(this.modifyDate);
        }
        return ret;
    }

    public boolean isSynced() {
        return synced;
    }

    public void setSynced(boolean synced) {
        this.synced = synced;
    }

    public Integer getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Integer hospitalId) {
        this.hospitalId = hospitalId;
    }


    @Override
    public int describeContents() {
        return hashCode();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(code);
        dest.writeString(name);
        dest.writeInt(extraBed ? 1 : 0);
        dest.writeString(region);
        dest.writeString(building);
        dest.writeString(floor);
        dest.writeInt(divisionId);
        dest.writeString(wardNumber);
        dest.writeInt(wardCapacity);
        dest.writeInt(wardGender);
        dest.writeString(nfcId);
        if (hospitalId != null) {
            dest.writeInt(hospitalId);
        } else {
            dest.writeInt(-1);
        }

        Bundle bundle = new Bundle();

        if (this.createDate != null) {
            bundle.putLong("createDate", this.createDate.getTime());
        }
        if (this.modifyDate != null) {
            bundle.putLong("modifyDate", this.modifyDate.getTime());
        }
    }

    public HospitalEntity getHospital() {
        return hospital;
    }

    public void setHospital(HospitalEntity hospital) {
        this.hospital = hospital;
    }

    public static final Parcelable.Creator<ScannedEntity> CREATOR = new Creator<ScannedEntity>() {
        @Override
        public ScannedEntity createFromParcel(Parcel source) {
            ScannedEntity scannedEntity = new ScannedEntity();
            scannedEntity.setCode(source.readString());
            scannedEntity.setName(source.readString());
            scannedEntity.setExtraBed(source.readInt() > 0);
            scannedEntity.setRegion(source.readString());
            scannedEntity.setBuilding(source.readString());
            scannedEntity.setFloor(source.readString());
            scannedEntity.setDivision(source.readInt());

            // about ward
            scannedEntity.setWardNumber(source.readString());
            scannedEntity.setWardCapacity(source.readInt());
            scannedEntity.setWardGender(source.readInt());

            scannedEntity.setNfcId(source.readString());
            scannedEntity.setHospitalId(source.readInt());
            Bundle bundle = source.readBundle();
            if (bundle.containsKey("createDate")) {
                scannedEntity.setCreateDate(new Date(bundle.getLong("createDate")));
            }
            if (bundle.containsKey("modifyDate")) {
                scannedEntity.setModifyDate(new Date(bundle.getLong("modifyDate")));
            }
            return null;
        }

        @Override
        public ScannedEntity[] newArray(int size) {
            return new ScannedEntity[size];
        }
    };

}

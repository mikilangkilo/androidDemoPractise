package com.highwho.qrbinding.entity;

import com.highwho.qrbinding.etag.ETag;
import com.highwho.qrbinding.etag.ETagException;
import com.highwho.qrbinding.etag.ETagLinker;
import com.highwho.qrbinding.etag.TagDataExtractor;
/**
 * Created by xyz on 3/3/16.
 */
public class SickbedETagLinker<E extends ETag> extends ETagLinker<E, ScannedEntity> {

    public SickbedETagLinker(TagDataExtractor<E, ScannedEntity> extractor) {
        super(extractor);
    }

    @Override
    public void linkTo(E eTag) {
        try {
            this.extractor.extract(eTag);
        } catch (ETagException e) {
            e.printStackTrace();
        }
    }
}

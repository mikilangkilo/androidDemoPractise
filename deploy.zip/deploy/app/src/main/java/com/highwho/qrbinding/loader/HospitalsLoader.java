package com.highwho.qrbinding.loader;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.highwho.qrbinding.App;
import com.highwho.qrbinding.common.http.WiseJsonArrayRequest;
import com.highwho.qrbinding.common.loader.volley.SqlVolleyArrayLoader;
import com.highwho.qrbinding.datasource.repository.Repository;
import com.highwho.qrbinding.entity.HospitalEntity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

/**
 * Created by xyz on 3/15/16.
 */
public class HospitalsLoader extends SqlVolleyArrayLoader<HospitalEntity, Integer> {
    public HospitalsLoader(Context context, RequestQueue requestQueue, boolean mSync, Repository<HospitalEntity, Integer> repository) {
        super(context, requestQueue, mSync, repository);
    }

    public HospitalsLoader(Context context, boolean mSync, Repository<HospitalEntity, Integer> repository) {
        super(context, mSync, repository);
    }

    public HospitalsLoader(Context context, Repository<HospitalEntity, Integer> repository) {
        super(context, repository);
    }

    @Override
    protected void dumpDataToDB(List<HospitalEntity> dataList, Repository<HospitalEntity, Integer> repository) {
        for (HospitalEntity entity : dataList) {
            entity = repository.save(entity);
        }
    }

    @Override
    protected List<HospitalEntity> queryDataFromDB(Repository<HospitalEntity, Integer> repository) {
        return repository.findAll("");
    }

    @Override
    protected HospitalEntity mapArrayItemToData(JSONArray jsonArray, int index) {
        try {
            JSONObject jsonObject = jsonArray.getJSONObject(index);
            HospitalEntity hospitalEntity = new HospitalEntity();
            hospitalEntity.setAddress(jsonObject.optString("address"));
            hospitalEntity.setId(jsonObject.getInt("id"));
            hospitalEntity.setName(jsonObject.optString("name"));
            return hospitalEntity;
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void onVolleyLoadedWithError(VolleyError error) {
        String text = "网络跟新失败:";
        if (error.networkResponse != null) {
            if (error.networkResponse.statusCode == 401) {
                text = text + "验证失败";
            } else {
                text = text + error.networkResponse.statusCode;
            }
        } else {
            text += error.getMessage();
        }
        Log.e("HospitalsLoader", "onVolleyLoadedWithError", error);
        Toast.makeText(this.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected WiseJsonArrayRequest initRequest(Response.Listener<JSONArray> listener, Response.ErrorListener errorListener) {
        return new WiseJsonArrayRequest(
                Request.Method.GET,
                App.preferenceReader(this.getContext()).getApiUri("/nodeset/spirit_hospitals"),
                null,
                listener,
                errorListener,
                App.authenticManager(this.getContext()).getToken());
    }
}

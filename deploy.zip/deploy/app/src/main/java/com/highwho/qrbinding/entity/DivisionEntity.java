package com.highwho.qrbinding.entity;

import android.provider.BaseColumns;

/**
 * Created by xyz on 7/25/16.
 */
public class DivisionEntity {
    public static abstract class Schema implements BaseColumns {
        public static final String TABLE_NAME = "divisions";
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_HOSPITAL_ID = "hospitalid";
    }

    private Integer id;
    private String name;
    private Integer hospitalId ;

    public DivisionEntity() {

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Integer hospitalId) {
        this.hospitalId = hospitalId;
    }

    @Override
    public String toString() {
        return this.getName();
    }
}

package com.highwho.qrbinding.common.authentic;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.highwho.qrbinding.App;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.CookieManager;
import java.net.HttpCookie;

/**
 * Created by xyz on 3/16/16.
 */
public class AuthenticManager {
    private static final String PREFERENCE_AUTHENTIC_NAME = "AUTHENTIC";
    private static final String PREFERENCE_TOKEN_NAME = "AUTHENTIC_TOKEN";
    private static final String COOKIE_SESSION_NAME = "HIS-SESSION";

    public interface LoginCallback extends Response.ErrorListener, Response.Listener<JSONObject> {

    }

    private RequestQueue requestQueue;
    private App app;
    private SharedPreferences preferences;

    public AuthenticManager(RequestQueue requestQueue, App app) {
        this.requestQueue = requestQueue;
        this.app = app;
        preferences = app.getContext().getApplicationContext().getSharedPreferences(PREFERENCE_AUTHENTIC_NAME, Context.MODE_PRIVATE);
    }

    public void login(String userName, String password, LoginCallback callback) {
        String url = app.getPreferenceReader()
                .getApiUri(
                        String.format("/token?username=%s&password=%s",
                        userName.trim(), password.trim()));
        Request<JSONObject> request = new JsonObjectRequest(
                Request.Method.POST,
                url,
                callback,
                callback
        );
        requestQueue.add(request);
    }

    public void loginByDefault(final String userName, String password) {
        LoginCallback loginCallback = new LoginCallback() {
            @Override
            public void onErrorResponse(VolleyError error) {
                String text = "登录失败";
                Toast.makeText(app.getContext().getApplicationContext(), text, Toast.LENGTH_LONG).show();
            }

            @Override
            public void onResponse(JSONObject response) {
                String theName = "用户" + userName;
                try {
                    String token = response.getString("token");
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString(PREFERENCE_TOKEN_NAME, token);
                    if (!editor.commit()) {
                        Log.e("WiseCookieStore", "cookie error");
                    }

                } catch (JSONException e) {
                    Log.e("AuthenticManager", "loginByDefault", e);
                }
                Toast.makeText(app.getContext().getApplicationContext(), theName + "登录成功", Toast.LENGTH_LONG).show();
            }
        };
        this.login(userName, password, loginCallback);
    }

    public String getToken() {
        return preferences.getString(PREFERENCE_TOKEN_NAME, "");
    }

}

package com.highwho.qrbinding.common.loader.volley;

import android.content.Context;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonRequest;

/**
 * Created by xyz on 3/12/16.
 */
public abstract class JsonLoader<D, JSON, R extends JsonRequest<JSON>> extends VolleyLoader<D, JSON, R> {
    public JsonLoader(Context context, RequestQueue requestQueue) {
        super(context, requestQueue);
    }

    public JsonLoader(Context context) {
        super(context);
    }

    @Override
    public void onResponse(JSON response) {
        D data = null;
        VolleyLoaderException exception = null;
        try {
            data = mapJsonToData(response);
        } catch (VolleyLoaderException e) {
            e.printStackTrace();
            exception = e;
        }
        setContent(data, exception);
        deliverResult(getContent());
    }

    protected abstract D mapJsonToData(JSON json) throws VolleyLoaderException;
}

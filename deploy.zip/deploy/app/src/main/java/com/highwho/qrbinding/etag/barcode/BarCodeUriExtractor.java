package com.highwho.qrbinding.etag.barcode;

import android.net.Uri;

import com.highwho.qrbinding.etag.ETag;
import com.highwho.qrbinding.etag.ETagException;
import com.highwho.qrbinding.etag.TagDataExtractor;

/**
 * Created by xyz on 3/8/16.
 */
public class BarCodeUriExtractor implements TagDataExtractor<BarCodeTag, Uri> {

    @Override
    public String getKey(BarCodeTag eTag) throws ETagException {
        return eTag.getStringContent();
    }

    @Override
    public Uri extract(BarCodeTag eTag) throws ETagException {
        if(eTag == null || eTag.getStringContent() == null){
            return null;
        }
        return Uri.parse(eTag.getStringContent());
    }
}

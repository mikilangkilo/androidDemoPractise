package com.highwho.qrbinding.etag;

import android.net.Uri;

/**
 * Created by xyz on 3/3/16.
 */
public abstract class WiseCodeExtractor<E extends ETag> implements TagDataExtractor<E, String> {
    protected TagDataExtractor<E, Uri> tagDataExtractor;

    public WiseCodeExtractor(TagDataExtractor<E, Uri> tagDataExtractor) {
        this.tagDataExtractor = tagDataExtractor;
    }

    @Override
    public String extract(E eTag) throws ETagException{
        Uri uri = tagDataExtractor.extract(eTag);
        String code = null;
        if(uri == null ) {
            throw new ETagException("can not get uri, uri is null");
        }
        if(uri.toString().matches("http://w-se\\.cn/([0-9a-zA-Z]+)")) {
            code = uri.getLastPathSegment();
        } else {
            throw new ETagException("uri format is not support");
        }
        return code;
    }
}

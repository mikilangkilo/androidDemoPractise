package com.highwho.qrbinding.datasource;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.highwho.qrbinding.entity.ScannedEntity;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by xyz on 2/22/16.
 */
public class HisDbHelper extends SQLiteOpenHelper {
    private static String CREATE_ENTITIES =
            "CREATE TABLE " + QrSickbed.Schema.TABLE_NAME + " (" +
                    QrSickbed.Schema._ID + " TEXT PRIMARY KEY," +
                    QrSickbed.Schema.COLUMN_BED_NUMBER + " TEXT," +
                    QrSickbed.Schema.COLUMN_DIVISION + " TEXT," +
                    QrSickbed.Schema.COLUMN_HID + " INTEGER," +
                    QrSickbed.Schema.COLUMN_NFC_ID + " TEXT," +
                    QrSickbed.Schema.COLUMN_CREATE_TIME + " DATETIME DEFAULT CURRENT_TIMESTAMP" +
                    ")";
    private static String CREATE_CHECK_ENTITIES =
            "CREATE TABLE " + "CHECK_CODE" + " (" +
                    QrSickbed.Schema._ID + " TEXT PRIMARY KEY," +
                    QrSickbed.Schema.COLUMN_CREATE_TIME + " DATETIME DEFAULT CURRENT_TIMESTAMP" +
                    ")";

    public static final int DATABASE_VERSION = 3;
    public static final String DATABASE_NAME = "his";
    private static final DateFormat DEFAULT_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());

    public HisDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void onCreate(SQLiteDatabase db) {
        System.out.println("onCreate sql helper");
        db.execSQL(CREATE_ENTITIES);
        db.execSQL(CREATE_CHECK_ENTITIES);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


    public Integer countQrSickbeds() {
        Cursor cursor = null;
        try {
            String[] projection = {"count(*)",};
            cursor = this.getReadableDatabase().query(
                    QrSickbed.Schema.TABLE_NAME,
                    projection, "", new String[]{},
                    null,
                    null,
                    null
            );
            int count = 0;
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                count = cursor.getInt(0);
            }
            return count;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public QrSickbed findById(String qrCode) {
        Cursor cursor = null;
        try {
            String[] projections = new String[]{
                    QrSickbed.Schema._ID,
                    QrSickbed.Schema.COLUMN_BED_NUMBER,
                    QrSickbed.Schema.COLUMN_DIVISION,
                    QrSickbed.Schema.COLUMN_HID,
                    "strftime('%m-%d %H:%M:%S'," + QrSickbed.Schema.COLUMN_CREATE_TIME + ",'localtime')",
                    QrSickbed.Schema.COLUMN_NFC_ID,
            };
            cursor = getReadableDatabase()
                    .query(QrSickbed.Schema.TABLE_NAME, projections, "_id=?", new String[]{qrCode}, null, null, null, null);
            if (cursor.getCount() <= 0) {
                return null;
            }
            cursor.moveToFirst();
            QrSickbed qrSickbed = new QrSickbed();
            qrSickbed.setQrCode(cursor.getString(0));
            qrSickbed.setBedNumber(cursor.getString(1));
            qrSickbed.setDivision(cursor.getString(2));
            qrSickbed.setHid(cursor.getInt(3));
            qrSickbed.setCreateTime(cursor.getString(4));
            qrSickbed.setNfcId(cursor.getString(5));
            return qrSickbed;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public QrSickbed insertOrUpdateQrSickbed(QrSickbed qrSickbed) {
        ContentValues contentValues = new ContentValues(4);
        contentValues.put(QrSickbed.Schema._ID, qrSickbed.getQrCode());
        contentValues.put(QrSickbed.Schema.COLUMN_BED_NUMBER, qrSickbed.getBedNumber());
        contentValues.put(QrSickbed.Schema.COLUMN_DIVISION, qrSickbed.getDivision());
        contentValues.put(QrSickbed.Schema.COLUMN_HID, qrSickbed.getHid());
        contentValues.put(QrSickbed.Schema.COLUMN_NFC_ID, qrSickbed.getNfcId());
        getWritableDatabase().insertWithOnConflict(QrSickbed.Schema.TABLE_NAME, null, contentValues, SQLiteDatabase.CONFLICT_REPLACE);
        return qrSickbed;
    }

    public List<QrSickbed> findAllQrSickbed() {
        Cursor cursor = null;
        try {
            String[] projections = new String[]{
                    QrSickbed.Schema._ID,
                    QrSickbed.Schema.COLUMN_BED_NUMBER,
                    QrSickbed.Schema.COLUMN_DIVISION,
                    QrSickbed.Schema.COLUMN_HID,
                    "strftime('%m-%d %H:%M:%S'," + QrSickbed.Schema.COLUMN_CREATE_TIME + ",'localtime')",
                    QrSickbed.Schema.COLUMN_NFC_ID,
            };
            cursor = getReadableDatabase()
                    .query(QrSickbed.Schema.TABLE_NAME, projections, "", new String[]{}, null, null, null, null);
            ArrayList<QrSickbed> arrayList = new ArrayList<>(cursor.getCount());
            while (cursor.moveToNext()) {
                QrSickbed qrSickbed = new QrSickbed();
                qrSickbed.setQrCode(cursor.getString(0));
                qrSickbed.setBedNumber(cursor.getString(1));
                qrSickbed.setDivision(cursor.getString(2));
                qrSickbed.setHid(cursor.getInt(3));
                qrSickbed.setCreateTime(cursor.getString(4));
                qrSickbed.setNfcId(cursor.getString(5));
                arrayList.add(qrSickbed);
            }
            return arrayList;
        } finally {
            if(cursor != null) cursor.close();
        }
    }

    public Cursor getCursorOfQrSickbeds() {
        String[] projections = new String[]{
                QrSickbed.Schema._ID,
                QrSickbed.Schema.COLUMN_BED_NUMBER,
                QrSickbed.Schema.COLUMN_DIVISION,
                QrSickbed.Schema.COLUMN_HID,
                QrSickbed.Schema.FORMAT_CREATE_TIME,
        };
        return getReadableDatabase()
                .query(QrSickbed.Schema.TABLE_NAME, projections, "", new String[]{}, null, null, QrSickbed.Schema.COLUMN_CREATE_TIME + " DESC", null);
    }

    public boolean deleteQrSickbedById(String id) {
        int result = getWritableDatabase().delete(QrSickbed.Schema.TABLE_NAME,  QrSickbed.Schema._ID + "= ?", new String[]{id});
        return result > 0;
    }

    public List<ScannedEntity> findSickbedByRange(int start, int limit) {
        Cursor cursor = null;
        String[] projections = new String[]{
                ScannedEntity.Schema._ID,
                ScannedEntity.Schema.COLUMN_ENTITY_NAME,
                ScannedEntity.Schema.COLUMN_DIVISION,
                ScannedEntity.Schema.COLUMN_HID,
                ScannedEntity.Schema.COLUMN_CREATE_TIME,
                ScannedEntity.Schema.COLUMN_NFC_ID,
        };
        try {
            String limitStr = String.format("%d, %d", start, limit);
            cursor = getReadableDatabase()
                    .query(ScannedEntity.Schema.TABLE_NAME, projections, "", new String[]{}, null, null, QrSickbed.Schema.COLUMN_CREATE_TIME + " DESC", limitStr);
            ArrayList<ScannedEntity> arrayList = new ArrayList<>(cursor.getCount());

            while (cursor.moveToNext()) {
                ScannedEntity sickbed = new ScannedEntity();
                sickbed.setCode(cursor.getString(0));
                sickbed.setName(cursor.getString(1));
                sickbed.setDivision(cursor.getInt(2));
                sickbed.setHospitalId(cursor.getInt(3));
                try {
                    sickbed.setCreateDate(DEFAULT_DATE_FORMAT.parse(cursor.getString(4)));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                sickbed.setNfcId(cursor.getString(5));
                arrayList.add(sickbed);
            }
            return arrayList;
        } finally {
            if(cursor != null) cursor.close();
        }
    }

    public void insertCheckCode(String code) throws SQLException{
        ContentValues contentValues = new ContentValues(1);
        contentValues.put(QrSickbed.Schema._ID, code);
        this.getWritableDatabase().insertOrThrow("CHECK_CODE", null, contentValues);
    }

    public String findCheckCodeTime(String code) throws SQLException{
        String[] columns = new String[]{"strftime('%m-%d %H:%M:%S'," + QrSickbed.Schema.COLUMN_CREATE_TIME + ",'localtime')"};
        Cursor cursor = this.getReadableDatabase().query("CHECK_CODE", columns, "_id=?", new String[]{code}, null, null, null, null);
        if (cursor.getCount() <= 0) {
            return null;
        }
        cursor.moveToFirst();
        String time = cursor.getString(0);
        cursor.close();
        return time;
    }

}

package com.highwho.qrbinding.common.loader;

import android.content.AsyncTaskLoader;
import android.content.Context;
import android.util.Log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by xyz on 3/7/16.
 */
public abstract class PageLoader<T> extends AsyncTaskLoader<List<T>> {
    // page number
    private final int startPage;
    private int index = 0;
    // page size
    public final int pageSize;
    private boolean requesting = false;
    private List<T> mCachedData;
    private int continueTime = 0;

    public PageLoader(Context context) {
        super(context);
        startPage = 0;
        pageSize = 10;
    }

    public PageLoader(Context context, int startIndex, int pageSize) {
        super(context);
        this.startPage = startIndex;
        this.pageSize = pageSize;
    }


    @Override
    protected void onStartLoading() {
        if (mCachedData != null) {
            deliverResult(mCachedData);
        }

        if (takeContentChanged()) {
            requestNextPage(index);
        } else if(mCachedData == null) {
            requestNextPage(startPage);
        }
    }

    @Override
    public List<T> loadInBackground() {
        return loadPageData(index, pageSize);
    }

    protected abstract List<T> loadPageData(int start, int pageSize);

    // called in the main thread
    public boolean requestNextPage(int start) {
        if (requesting) {
            return false;
        }
        if( index == start) {
            continueTime ++;
            if(continueTime > 2) {
                return false;
            }
        } else {
            continueTime = 0;
        }
        index = start;
        requesting = true;
        this.onContentChanged();
        return true;
    }

    @Override
    public void deliverResult(List<T> data) {
        if (data == null) return;
        mCachedData = data;
        super.deliverResult(mCachedData);
        requesting = false;
    }

    /**
     * Handles a request to stop the Loader.
     */
    @Override
    protected void onStopLoading() {
        // Attempt to cancel the current load task if possible.
        cancelLoad();
        releaseCacheData();
        continueTime = 0;
    }

    /**
     * Handles a request to cancel a load.
     */
    @Override
    public void onCanceled(List<T> data) {
        super.onCanceled(data);

        // At this point we can release the resources associated with 'apps'
        // if needed.
        releaseCacheData();
    }

    /**
     * Handles a request to completely reset the Loader.
     */
    @Override
    protected void onReset() {
        super.onReset();

        // Ensure the loader is stopped
        onStopLoading();

        // At this point we can release the resources associated with 'apps'
        // if needed.
        releaseCacheData();
    }

    protected void releaseCacheData() {
        this.mCachedData = null;
    }

    public int getIndex() {
        return index;
    }
}

package com.highwho.qrbinding.common.http;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by xyz on 6/23/16.
 */
public class WiseJsonObjectRequest extends JsonObjectRequest {
    private String token;

    public WiseJsonObjectRequest(int method, String url, String requestBody, Response.Listener<JSONObject> listener, Response.ErrorListener errorListener, String token) {
        super(method, url, requestBody, listener, errorListener);
        this.token = token;
    }

    @Override
    public Map<String, String> getHeaders() throws AuthFailureError {
        Map<String, String> heardes = new HashMap<>(super.getHeaders());
        heardes.put("token", token);
        return heardes;
    }
}

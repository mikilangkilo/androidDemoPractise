package com.highwho.qrbinding.fragment;

import android.content.Context;
import android.view.View;

import com.highwho.qrbinding.R;
import com.highwho.qrbinding.common.view.adapter.DataBindingArrayAdapter;
import com.highwho.qrbinding.entity.HospitalEntity;

/**
 * Created by xyz on 3/14/16.
 */
public class HospitalsSelectAdapter extends DataBindingArrayAdapter<HospitalEntity, Integer> {

    public HospitalsSelectAdapter(Context context, int resource, int variable) {
        super(context, resource, variable);
    }

    @Override
    protected View onGetRemarkView(View view, int position) {
        view.setBackgroundColor(getContext().getResources().getColor(R.color.colorPromptSuccess));
        return view;
    }

    @Override
    protected boolean equalRemark(Integer key, int position, HospitalEntity data) {
        return key != null && key.equals(data.getId());
    }
}

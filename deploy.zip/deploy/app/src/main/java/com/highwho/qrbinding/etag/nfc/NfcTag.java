package com.highwho.qrbinding.etag.nfc;

import android.net.Uri;
import android.nfc.Tag;

import com.highwho.qrbinding.etag.ETag;

/**
 * Created by xyz on 3/3/16.
 */
public class NfcTag extends ETag {
    private Tag tag;

    public NfcTag(Tag tag) {
        this.tag = tag;
    }

    public Tag getSystemTag() {
        return tag;
    }

}

package com.highwho.qrbinding.etag;

/**
 * Created by xyz on 3/3/16.
 */
public class ETagException extends Exception {
    public ETagException() {

    }

    public ETagException(String detailMessage) {
        super(detailMessage);
    }

    public ETagException(String detailMessage, Throwable throwable) {
        super(detailMessage, throwable);
    }

    public ETagException(Throwable throwable) {
        super(throwable);
    }
}

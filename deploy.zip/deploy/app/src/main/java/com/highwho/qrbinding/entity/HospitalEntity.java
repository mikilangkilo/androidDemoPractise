package com.highwho.qrbinding.entity;

import android.provider.BaseColumns;

/**
 * Created by xyz on 3/9/16.
 */
public class HospitalEntity {
    public static abstract class Schema implements BaseColumns {
        public static final String TABLE_NAME = "hospitals";
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_ADDRESS = "address";
    }


    private Integer id;
    private String name;
    private String address;

    public HospitalEntity() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}

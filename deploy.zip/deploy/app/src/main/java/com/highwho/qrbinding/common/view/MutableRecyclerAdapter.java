package com.highwho.qrbinding.common.view;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xyz on 3/7/16.
 */
public abstract class MutableRecyclerAdapter<V extends View, T> extends RecyclerView.Adapter<MutableRecyclerAdapter.ViewHolder<V>> {

    public interface OnRecycleItemTouchListener<V extends View> {
        boolean onItemClickEvent(ViewHolder<V> viewHolder, View v);
    }

    private OnRecycleItemTouchListener<V> onRecycleItemTouchListener;

    private List<T> data;

    protected List<T> getData() {
        return data;
    }

    public static class ViewHolder<V extends View> extends BindingViewHolder<V> {
        private V itemView;

        private View.OnClickListener getOnClickListener(final OnRecycleItemTouchListener<V> listener) {
            return new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null && listener.onItemClickEvent(ViewHolder.this, v)) return;
                    v.requestFocus();
                    v.setSelected(true);
                }
            };
        }

        public ViewHolder(V itemView, OnRecycleItemTouchListener<V> onRecycleItemTouchListener) {
            super(itemView);
            this.itemView = itemView;
            itemView.setOnClickListener(getOnClickListener(onRecycleItemTouchListener));
        }

        public View getItemView() {
            return itemView;
        }
    }

    public MutableRecyclerAdapter(List<T> data) {
        this.data = data;
    }

    public MutableRecyclerAdapter() {
        this.data = new ArrayList<>();
    }

    //create the view for the view holder
    protected abstract V createView(ViewGroup parent, int viewType);

    @Override
    public ViewHolder<V> onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder<V>(createView(parent, viewType), this.onRecycleItemTouchListener);
    }

    @Override
    public void onBindViewHolder(ViewHolder<V> holder, int position, List<Object> payloads) {
        super.onBindViewHolder(holder, position, payloads);
    }

    @Override
    public int getItemCount() {
        return data != null ? data.size() : 0;
    }


    public void setOnRecycleItemTouchListener(OnRecycleItemTouchListener<V> listener) {
        this.onRecycleItemTouchListener = listener;
    }

    public T getItemData(int index) {
        return this.getData().get(index);
    }

    // call in the main thread
    public synchronized void updateData(List<T> newData, int start, boolean update) {
        try {
            int index = getItemCount() - start;
            int size = newData.size();
            if (index >= 0 && index < size) {
                this.getData().addAll(newData.subList(index, size));
                if (update) {
//                    this.notifyItemRangeInserted(index, size);
                    this.notifyDataSetChanged();
                }
            }
        } catch (IndexOutOfBoundsException | IllegalArgumentException e) {
            Log.e(this.getClass().getSimpleName(), "updateData", e);
        }

    }

    // call in the main thread
    public synchronized void clearData(boolean update) {
        if (this.getData() != null) {
            this.getData().clear();
        }
        if (update) {
            this.notifyDataSetChanged();
        }
    }
}

package com.highwho.qrbinding;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.highwho.qrbinding.datasource.HisDbHelper;
import com.highwho.qrbinding.datasource.QrSickbed;

/**
 * Created by xyz on 2/23/16.
 */
public class QrSickbedList extends Activity {
    private HisDbHelper hisDbHelper;
    private SimpleCursorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        System.out.println("QrSickbedList create");

        ListView listView = new ListView(this);

        String[] fromColumns = {QrSickbed.Schema._ID, QrSickbed.Schema.COLUMN_BED_NUMBER, QrSickbed.Schema.COLUMN_DIVISION, QrSickbed.Schema.FORMAT_CREATE_TIME};
        int[] toViews = {R.id.sickbed_qrCode, R.id.sickbed_number, R.id.sickbed_division, R.id.sickbed_time};

        this.hisDbHelper = new HisDbHelper(this);
        adapter = new SimpleCursorAdapter(this,
                R.layout.qrsickbed_row, this.hisDbHelper.getCursorOfQrSickbeds(), fromColumns, toViews, 0);

        listView.setAdapter(adapter);

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                deleteItem(view);
                return true;
            }
        });
        setContentView(listView);
    }

    private void deleteItem(final View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("操作")
                .setMessage("确定删除么？")
                .setPositiveButton("是", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        TextView textView = (TextView) view.findViewById(R.id.sickbed_qrCode);
                        String qrCode = textView.getText().toString();
                        if (hisDbHelper.deleteQrSickbedById(qrCode)) {
                            Toast.makeText(view.getContext(), "删除成功", Toast.LENGTH_SHORT).show();
                            if ( adapter.getCursor().isClosed()) {adapter.getCursor().close();}
                            adapter.changeCursor(hisDbHelper.getCursorOfQrSickbeds());
                        } else {
                            Toast.makeText(view.getContext(), "删除失败", Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .setNegativeButton("否", null)
                .show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(!this.adapter.getCursor().isClosed()) {
            this.adapter.getCursor().close();
        }

    }
}

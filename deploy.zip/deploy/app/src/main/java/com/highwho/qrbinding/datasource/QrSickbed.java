package com.highwho.qrbinding.datasource;

import android.provider.BaseColumns;

import java.util.Date;

/**
 * Created by xyz on 2/22/16.
 */
public class QrSickbed {
    public static abstract class Schema implements BaseColumns {
        public static final String TABLE_NAME = "qr_sickbed";
        public static final String COLUMN_BED_NUMBER = "bed_number";
        public static final String COLUMN_DIVISION = "division";
        public static final String COLUMN_NFC_ID = "nfc_id";
        public static final String COLUMN_HID = "hid";
        public static final String COLUMN_CREATE_TIME = "createtime";
        public static final String FORMAT_CREATE_TIME = "strftime('%m-%d %H:%M:%S'," + QrSickbed.Schema.COLUMN_CREATE_TIME + ",'localtime')";

    }

    private String qrCode;
    private String bedNumber;
    private String division;
    private Integer hid = 3;
    private String nfcId = "";
    private String createTime;
    public QrSickbed() {

    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public String getBedNumber() {
        return bedNumber;
    }

    public void setBedNumber(String bedNumber) {
        this.bedNumber = bedNumber;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public Integer getHid() {
        return hid;
    }

    public void setHid(Integer hid) {
        this.hid = hid;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getNfcId() {
        return nfcId;
    }

    public void setNfcId(String nfcId) {
        this.nfcId = nfcId;
    }
}

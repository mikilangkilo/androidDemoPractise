package com.highwho.qrbinding.nfc;

/**
 * Created by xyz on 2/28/16.
 */
public class SickbedTagException extends Exception {
    public SickbedTagException() {
    }

    public SickbedTagException(String detailMessage) {
        super(detailMessage);
    }

    public SickbedTagException(String detailMessage, Throwable throwable) {
        super(detailMessage, throwable);
    }

    public SickbedTagException(Throwable throwable) {
        super(throwable);
    }
}

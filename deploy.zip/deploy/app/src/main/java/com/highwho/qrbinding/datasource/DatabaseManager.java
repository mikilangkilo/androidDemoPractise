package com.highwho.qrbinding.datasource;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by xyz on 3/13/16.
 */
public class DatabaseManager {
    private static DatabaseManager wiseInstance;

//    private AtomicInteger mOpenCounter = new AtomicInteger(0);
    private SQLiteOpenHelper mDatabaseHelper;
    private SQLiteDatabase mDatabase;

    public static synchronized DatabaseManager initializeInstance(SQLiteOpenHelper helper) {
        DatabaseManager instance = new DatabaseManager();
        instance.mDatabaseHelper = helper;
        return instance;
    }

    public static synchronized DatabaseManager getWiseInstance(Context context) {
        if (wiseInstance == null) {
            WiseDbHelper wiseDbHelper = new WiseDbHelper(context.getApplicationContext());
            wiseInstance = initializeInstance(wiseDbHelper);
        }
        return wiseInstance;
    }

    public synchronized SQLiteDatabase openDatabase() {
        if (mDatabase == null || mDatabase.isOpen()) {
            // Opening new database
            mDatabase = mDatabaseHelper.getWritableDatabase();
        }
        return mDatabase;
    }

//    public synchronized void closeDatabase() {
//        if (mOpenCounter.decrementAndGet() == 0) {
//            // Closing database
//            mDatabase.close();
//        }
//        mOpenCounter.compareAndSet(-1, 0);
//    }
}

package com.highwho.qrbinding.fragment;

import android.app.Fragment;
import android.content.Intent;
import android.content.res.Resources;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.highwho.qrbinding.BR;
import com.highwho.qrbinding.R;
import com.highwho.qrbinding.business.SEntityOperationHandler;
import com.highwho.qrbinding.datasource.DatabaseManager;
import com.highwho.qrbinding.datasource.repository.DivisionRepository;
import com.highwho.qrbinding.entity.DivisionEntity;
import com.highwho.qrbinding.entity.HospitalEntity;
import com.highwho.qrbinding.entity.ScannedEntity;
import com.highwho.qrbinding.etag.ETagDetector;
import com.highwho.qrbinding.etag.ETagException;
import com.highwho.qrbinding.etag.ETagManager;
import com.highwho.qrbinding.etag.barcode.BarCodeDetector;
import com.highwho.qrbinding.etag.barcode.BarCodeTag;
import com.highwho.qrbinding.etag.nfc.NfcTag;
import com.highwho.qrbinding.etag.nfc.NfcTagDetector;

import java.util.List;

/**
 * Created by xyz on 3/8/16.
 */
public class ScanOperFragment extends Fragment implements SEntityOperationHandler.OperationListener {
    public interface OnSEntitySavedListener {
        void onSickbedSaved(ScannedEntity scannedEntity);
    }

    public static final String SICKBED_ENTITY_PARAMETER_NAME = "sickbed_entity_parameter";

    private static final int PROMPT_LEVEL_DEFAULT = R.color.colorPromptDefault;
    private static final int PROMPT_LEVEL_INFO = R.color.colorPromptInfo;
    private static final int PROMPT_LEVEL_ERROR = R.color.colorPromptError;
    private static final int PROMPT_LEVEL_SUCCESS = R.color.colorPromptSuccess;
    private static final int PROMPT_LEVEL_WARNING = R.color.colorPromptWarning;

    private OnSEntitySavedListener onSEntitySavedListener;

    private ViewDataBinding viewDataBinding;

    private NfcTagDetector nfcTagDetector;
    private BarCodeDetector barCodeTagDetector;

    private EditText numberEdit;
    private Spinner divisionSpinner;
    private Spinner categorySpinner;
    private EditText regionEdit;
    private TextView codeText;
    private TextView hidText;
    private TextView nfcIdText;
    private TextView hosNameText;

    private TextView buildingEdit;
    private TextView floorEdit;

    private TextView wardNumberEdit;
    private TextView wardCapaityEdit;
    private RadioGroup wardGenderGroup;
    private CheckBox extraCheckbox;

    private SEntityOperationHandler eventHandler;
    private DivisionRepository divisionRepository;
    /* region code for time life */

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view;
        if (savedInstanceState == null) {
            ScannedEntity entity = new ScannedEntity();
            if (getArguments() != null) {
                Object object = getArguments().getParcelable(SICKBED_ENTITY_PARAMETER_NAME);
                if (object != null && object instanceof ScannedEntity) {
                    entity = (ScannedEntity) object;
                }
            }
            viewDataBinding = DataBindingUtil.inflate(inflater, R.layout.sickbed_oper, container, false);
            viewDataBinding.setVariable(BR.sEntity, entity);
            view = viewDataBinding.getRoot();

        } else {
            view = super.onCreateView(inflater, container, savedInstanceState);
        }
        divisionRepository = new DivisionRepository(DatabaseManager.getWiseInstance(this.getActivity()));
        setUpButton(view);
        setUpTextView(view);
        setUpCategorySpinner(view);

        this.divisionSpinner = (Spinner) view.findViewById(R.id.sickbed_division_spinner);

//        setUpDivisionSpinner(view);
        setUpETagDetector();
        eventHandler = new SEntityOperationHandler(this, DatabaseManager.getWiseInstance(getActivity()));
        if(getActivity() instanceof OnSEntitySavedListener) {
            this.onSEntitySavedListener = (OnSEntitySavedListener)getActivity();
        }
        return view;
    }


    @Override
    public void onResume() {
        super.onResume();
        try {
            if (nfcTagDetector != null) {
                nfcTagDetector.start();
            }
        } catch (ETagException e) {
            updatePrompt("启动nfc检测失败", PROMPT_LEVEL_WARNING);
            showToastError(e);
            e.printStackTrace();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        try {
            if (nfcTagDetector != null) {
                nfcTagDetector.stop();
            }
        } catch (ETagException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onStop() {
        super.onStop();
        eventHandler.stop();
    }

    /* region code for business logic */

    public void filterIntent(int requestCode, int resultCode, Intent data) {
        if (this.barCodeTagDetector != null) {
            this.barCodeTagDetector.filterIntent(data, requestCode, resultCode);
        }
        if (this.nfcTagDetector != null) {
            this.nfcTagDetector.filterIntent(data, requestCode, resultCode);
        }
    }

    @Override
    public void onViewStateRestored(Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
        if (eventHandler != null) {
            eventHandler.stop();
        }
    }

    @Override
    public void onSavedSickbed(SEntityOperationHandler.CallbackArguments arguments) {
        updatePrompt(
                arguments.getPrompt(),
                callbackLevelToColorLevel(arguments.getCallbackLevel()));

        if (arguments.getDetail() != null && arguments.getDetail().length() > 0) {
            showToastDetail(arguments.getDetail());
        }
    }

    @Override
    public void onDetectSickbed(SEntityOperationHandler.CallbackArguments arguments) {
        this.clear();
        updateSEntityInfo(
                arguments.getScannedEntity(),
                arguments.getPrompt(),
                callbackLevelToColorLevel(arguments.getCallbackLevel()));

        if (arguments.getDetail() != null && arguments.getDetail().length() > 0) {
            showToastDetail(arguments.getDetail());
        }
    }

    // call back for instance
    public boolean onHospitalChange(HospitalEntity entity) {
        View view = this.getView();
        if (view == null) return false;
        // set view text from data

        if (entity != null && entity.getId() != null) {
            hosNameText.setText(entity.getName());
            hidText.setText(String.valueOf(entity.getId()));
            setUpDivisionSpinner(this.getView(), divisionRepository.findByHospitalId(entity.getId()));
        } else {
            hosNameText.setText("");
            hidText.setText("");
        }
        return true;
    }

    //R.id.scan_barcode_btn
    private void startScanBarCode() {
        if (barCodeTagDetector != null) {
            barCodeTagDetector.start();
        }
    }

    //R.id.save_sickbed_btn
    private void saveSickbed() {
        if (eventHandler != null) {
            eventHandler.saveSickbed(assembleSEntity());
        }
    }

    public void clear() {
        updateSEntityInfo(null, null, PROMPT_LEVEL_DEFAULT);
    }


    /* region code for view to data */
    private ScannedEntity assembleSEntity() {
        ScannedEntity scannedEntity = new ScannedEntity();
        scannedEntity.setCode(codeText.getText().toString());
        scannedEntity.setExtraBed(extraCheckbox.isChecked());
        scannedEntity.setRegion(regionEdit.getText().toString().trim());
        scannedEntity.setBuilding(buildingEdit.getText().toString().trim());
        scannedEntity.setFloor(floorEdit.getText().toString().trim());
        scannedEntity.setName(numberEdit.getText().toString().trim());
        if (divisionSpinner != null && divisionSpinner.getSelectedItem() != null){
            scannedEntity.setDivision(((DivisionEntity)divisionSpinner.getSelectedItem()).getId());
        } else {
            scannedEntity.setDivision(null);
        }
//        scannedEntity.setDivision(divisionEdit.getText().toString().trim());

        scannedEntity.setWardNumber(wardNumberEdit.getText().toString());
        if (wardCapaityEdit.getText() != null && !wardCapaityEdit.getText().toString().equals("")) {
            scannedEntity.setWardCapacity(Integer.valueOf(wardCapaityEdit.getText().toString()));
        }

        switch (categorySpinner.getSelectedItem().toString()) {
            case "病床":
                scannedEntity.setCategory("sickbed");
                break;
            case "诊室":
                scannedEntity.setCategory("consulting_room");
                break;
            case "窗口":
                scannedEntity.setCategory("wicket");
                break;
            case "公共设施":
                scannedEntity.setCategory("facility");
                break;
        }

        switch (wardGenderGroup.getCheckedRadioButtonId()) {
            case R.id.gender_other_radio:
                scannedEntity.setWardGender(0);
                break;
            case R.id.gender_male_radio:
                scannedEntity.setWardGender(1);
                break;
            case R.id.gender_female_radio:
                scannedEntity.setWardGender(2);
                break;
            default:
                scannedEntity.setWardGender(0);
        }

        scannedEntity.setNfcId(nfcIdText.getText().toString());
        if (hidText.getText() != null && hidText.getText().length() > 0 ) {
            int id = Integer.valueOf((String) hidText.getText());
            scannedEntity.setHospitalId(id);
            HospitalEntity hospitalEntity = new HospitalEntity();
            hospitalEntity.setId(id);
            hospitalEntity.setName(hosNameText.getText().toString());
            scannedEntity.setHospital(hospitalEntity);
        }
        return scannedEntity;
    }


    private int getBedNumberAutoUpdate() {
        int autoOperation = SEntityOperationHandler.NUMBER_AUTO_CLOSE;
        View view = getView();
        if (view != null) {
            view = view.findViewById(R.id.sickbed_number_operation_seekBar);
            if (view instanceof SeekBar) {
                autoOperation = ((SeekBar) view).getProgress();
            }
        }
        return autoOperation;
    }


    /* region code for operation view */

    protected void updateSEntityInfo(ScannedEntity newEntity, String state, int level) {
        ScannedEntity entity = newEntity == null ? new ScannedEntity() : newEntity;
        if (viewDataBinding != null) {
            viewDataBinding.setVariable(BR.sEntity, entity);
            viewDataBinding.executePendingBindings();
        }
        int genderRadioId = 0;
        switch (entity.getWardGender()) {
            case 0:
                genderRadioId = R.id.gender_other_radio;
                break;
            case 1:
                genderRadioId = R.id.gender_male_radio;
                break;
            case 2:
                genderRadioId = R.id.gender_female_radio;
                break;
            default:
                genderRadioId = R.id.gender_other_radio;
        }
        wardGenderGroup.check(genderRadioId);

        divisionSpinner.setSelection(0);
        categorySpinner.setSelection(0);

        HospitalEntity hospitalEntity = entity.getHospital();
        if (hospitalEntity == null && entity.getHospitalId() != null) {
            hospitalEntity = new HospitalEntity();
            hospitalEntity.setId(entity.getHospitalId());
        }
        onHospitalChange(entity.getHospital());

        if (newEntity != null) {
            if (divisionSpinner.getAdapter() != null ) {
                for (int position = 0 ;position < divisionSpinner.getAdapter().getCount(); position++) {
                    DivisionEntity division = (DivisionEntity) divisionSpinner.getItemAtPosition(position);
                    if(division.getId().equals(newEntity.getDivision())) {
                        Log.d("updateSEntityInfo", "DivisionEntity id:" + division.getId().toString() + " equal:" + newEntity.getDivision() + " position:" + String.valueOf(position));
                        divisionSpinner.setSelection(position);
                        break;
                    }
                }
            }

            if (newEntity.getCategory() != null) {
                String categoryItemName = null;
                switch (newEntity.getCategory()) {
                    case "sickbed":
                        categoryItemName = "病床";
                        break;
                    case "consulting_room":
                        categoryItemName = "诊室";
                        break;
                    case "wicket":
                        categoryItemName = "窗口";
                        break;
                    case "facility":
                        categoryItemName = "公共设施";
                        break;
                }

                for (int position = 0 ;position < categorySpinner.getAdapter().getCount(); position++) {
                    CharSequence category = (CharSequence) categorySpinner.getItemAtPosition(position);
                    if(category.equals(categoryItemName)) {
                        categorySpinner.setSelection(position);
                        break;
                    }
                }
            }
        }

        updatePrompt(state, level);
    }

    private int callbackLevelToColorLevel(int callbackLevel) {
        switch (callbackLevel) {
            case SEntityOperationHandler.CALLBACK_LEVEL_INFO:
                return PROMPT_LEVEL_INFO;
            case SEntityOperationHandler.CALLBACK_LEVEL_SUCCESS:
                return PROMPT_LEVEL_SUCCESS;
            case SEntityOperationHandler.CALLBACK_LEVEL_WARNING:
                return PROMPT_LEVEL_WARNING;
            case SEntityOperationHandler.CALLBACK_LEVEL_ERROR:
                return PROMPT_LEVEL_ERROR;
            default:
                return PROMPT_LEVEL_DEFAULT;
        }
    }

    private void updatePrompt(String content, int level) {
        if (getView() == null) {
            return;
        }
        View view = getView().findViewById(R.id.sickbed_operation_state_text);
        if (view instanceof TextView) {
            TextView textView = (TextView) view;
            if (content == null) {
                content = "";
            }
            textView.setText(content);
            try {
                textView.setTextColor(getResources().getColor(level));
            } catch (Resources.NotFoundException e) {
                e.printStackTrace();
            }
        }
    }


    private void setUpButton(View view) {
        (view.findViewById(R.id.scan_barcode_btn)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startScanBarCode();
            }
        });

        (view.findViewById(R.id.sickbed_binding_btn)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSickbed();
            }
        });
    }

    private void setUpTextView(View view) {
        if (view == null) return;
        numberEdit = (EditText) view.findViewById(R.id.sickbed_number_edit);
//        divisionEdit = (EditText) view.findViewById(R.id.sickbed_division_spinner);
        regionEdit = (EditText) view.findViewById(R.id.sickbed_region_edit);
        buildingEdit = (EditText) view.findViewById(R.id.sickbed_building_edit);
        floorEdit = (EditText) view.findViewById(R.id.sickbed_floor_edit);
        codeText = (TextView) view.findViewById(R.id.sickbed_operation_code_text);
        hidText = (TextView) view.findViewById(R.id.sickbed_operation_id_text);
        nfcIdText = (TextView) view.findViewById(R.id.nfc_id_text);
        hosNameText = (TextView) view.findViewById(R.id.sickbed_hospital_text);

        wardNumberEdit = (TextView) view.findViewById(R.id.sickbed_ward_number_edit);
        wardCapaityEdit = (TextView) view.findViewById(R.id.sickbed_ward_capacity_edit);
        wardGenderGroup = (RadioGroup) view.findViewById(R.id.sickbed_ward_gender_radio_group);
        wardGenderGroup.check(R.id.gender_other_radio);
        extraCheckbox = (CheckBox) view.findViewById(R.id.sickbed_extra_check);
    }

    private void setUpETagDetector() {
        final ETagManager eTagManager = new ETagManager(this.getActivity());
        nfcTagDetector = eTagManager.getNfcDetector();
        barCodeTagDetector = eTagManager.getBarCodeDetector();
        nfcTagDetector.setETagListener(new ETagDetector.DetectETagListener<NfcTag>() {
            @Override
            public boolean onDetectETag(NfcTag eTag) {
                eventHandler.detectedETag(eTagManager.getWiseNfcExtractor(), eTag, getBedNumberAutoUpdate(), assembleSEntity());
                return true;
            }
        });

        barCodeTagDetector.setETagListener(new ETagDetector.DetectETagListener<BarCodeTag>() {
            @Override
            public boolean onDetectETag(BarCodeTag eTag) {
                eventHandler.detectedETag(eTagManager.getWiseBarcodeExtractor(), eTag, getBedNumberAutoUpdate(), assembleSEntity());
                return true;
            }
        });
    }

    private void setUpDivisionSpinner(View view, List<DivisionEntity> divisions) {
        if(divisionSpinner == null) {
            divisionSpinner = (Spinner) view.findViewById(R.id.sickbed_division_spinner);
        }
        ArrayAdapter<DivisionEntity> adapter = new ArrayAdapter<DivisionEntity>(this.getActivity(), android.R.layout.simple_spinner_item, divisions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        divisionSpinner.setAdapter(adapter);
    }

    private void setUpCategorySpinner(View view) {
        final Spinner spinner = (Spinner) view.findViewById(R.id.entity_category_spinner);
        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this.getActivity(), R.array.scan_entity_categories, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        categorySpinner = spinner;
    }

    private void showToastError(Exception e) {
        Toast.makeText(this.getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
    }

    private void showToastDetail(String detail) {
        Toast.makeText(this.getActivity(), detail, Toast.LENGTH_LONG).show();
    }
}
